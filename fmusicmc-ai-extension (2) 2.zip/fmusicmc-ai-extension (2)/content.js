// content.js — v1.8.1 (fmusicmc)
(function () {
  const STYLE_ID = 'fmusicmc-ai-style';
  const BTN_ID   = 'fmusicmc-ai-btn';
  const PANEL_ID = 'fmusicmc-ai-panel';

  let ownTabId = null;
  let cachedOwnUsername = null;

  // cached settings for the link-capture feature
  let listModeOn = false;
  let botModeCache = 'auto';
  let uiLang = 'fa';

  chrome.runtime.sendMessage({ type: 'GET_TAB_ID' }, res => {
    if (res?.tabId) ownTabId = res.tabId;
  });

  const getSync = keys => new Promise(r => chrome.storage.sync.get(keys, r));

  chrome.storage.sync.get(['listMode', 'botMode', 'popupLang'], d => {
    listModeOn   = !!d.listMode;
    botModeCache = d.botMode || 'auto';
    uiLang       = d.popupLang || 'fa';
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    if (changes.listMode)  listModeOn   = !!changes.listMode.newValue;
    if (changes.botMode)   botModeCache = changes.botMode.newValue || 'auto';
    if (changes.popupLang) uiLang       = changes.popupLang.newValue || 'fa';
    if (changes.tone) {
      const sel = document.querySelector('#fm-tone');
      if (sel && changes.tone.newValue) sel.value = changes.tone.newValue;
    }
  });

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const link = document.createElement('link');
    link.id   = STYLE_ID;
    link.rel  = 'stylesheet';
    link.href = chrome.runtime.getURL('styles/overlay.css');
    document.documentElement.appendChild(link);
  }

  function createPanel() {
    let panel = document.getElementById(PANEL_ID);
    if (panel) return panel;

    panel = document.createElement('div');
    panel.id        = PANEL_ID;
    panel.className = 'fm-overlay';
    panel.innerHTML = `
      <div class="fm-header">
        <img src="${chrome.runtime.getURL('icons/icon128.png')}" class="fm-logo" alt="fmusicmc">
        <div class="fm-title">fmusicmc ai Pro</div>
        <button class="fm-close" aria-label="Close">×</button>
      </div>
      <div class="fm-body">
        <textarea id="fm-input" class="fm-text" placeholder="متن توییت..."></textarea>
        <div class="fm-controls">
          <select id="fm-tone">
            <option value="friendly">دوستانه</option>
            <option value="professional">حرفه‌ای</option>
            <option value="witty">طنز</option>
            <option value="analytical">تحلیلی</option>
            <option value="neutral">خنثی</option>
          </select>
          <button id="fm-generate" class="fm-primary">⚡ تولید پاسخ</button>
        </div>
        <div class="fm-output-wrap">
          <textarea id="fm-output" class="fm-text fm-output-text" placeholder="پاسخ هوش مصنوعی..." readonly></textarea>
        </div>
        <div class="fm-actions">
          <button id="fm-insert" class="fm-secondary">⬆️ درج در ریپلای</button>
          <button id="fm-copy" class="fm-ghost">📋 کپی</button>
        </div>
        <div class="fm-status" id="fm-status"></div>
      </div>
    `;
    document.body.appendChild(panel);
    panel.querySelector('.fm-close')?.addEventListener('click', () => panel.classList.remove('open'));
    return panel;
  }

  function ensureButton() {
    if (document.getElementById(BTN_ID)) return;
    const btn = document.createElement('button');
    btn.id        = BTN_ID;
    btn.className = 'fm-fab';
    btn.title     = 'fmusicmc ai';
    btn.innerHTML = `<img src="${chrome.runtime.getURL('icons/icon128.png')}" style="width:20px;height:20px;border-radius:50%;vertical-align:middle;margin-left:6px;"> fmusicmc ai`;
    btn.addEventListener('click', () => onOpen());
    document.body.appendChild(btn);
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function getActiveTweetText() {
    const detail = document.querySelector('article [data-testid="tweetText"]');
    if (detail?.innerText?.trim()) return detail.innerText.trim();
    return '';
  }

  // ─── List mode: capture tweet links and save them to the queue ─────────────
  function normalizeTweetUrl(href) {
    try {
      const u = new URL(href, location.origin);
      if (!/(^|\.)(x|twitter)\.com$/.test(u.hostname)) return null;
      const m = u.pathname.match(/^\/([^/]+)\/status\/(\d+)/);
      if (!m) return null;
      return `https://x.com/${m[1]}/status/${m[2]}`;
    } catch { return null; }
  }

  function showToast(msg, ok = true) {
    let t = document.getElementById('fmusicmc-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'fmusicmc-toast';
      t.style.cssText = 'position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:2147483647;' +
        'padding:9px 16px;border-radius:12px;font:600 13px ui-sans-serif,system-ui,Tahoma,sans-serif;' +
        'color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.4);transition:opacity .25s;pointer-events:none;direction:rtl;';
      document.body.appendChild(t);
    }
    t.style.background = ok ? '#1e3a2f' : '#3a2f1e';
    t.style.border = `1px solid ${ok ? '#57f287' : '#faa61a'}`;
    t.textContent = msg;
    t.style.opacity = '1';
    clearTimeout(t._to);
    t._to = setTimeout(() => { t.style.opacity = '0'; }, 1800);
  }

  function addToList(url) {
    const fa = uiLang === 'fa';
    try {
      chrome.runtime.sendMessage({ type: 'ADD_TO_QUEUE', url }, res => {
        if (chrome.runtime.lastError || !res?.ok) {
          showToast(fa ? '⚠️ اکستنشن به‌روز شده، صفحه X را رفرش کنید' : '⚠️ Extension updated, please refresh this X tab', false);
          return;
        }
        if (res.added) showToast(fa ? `✅ به لیست اضافه شد (${res.count})` : `✅ Added to list (${res.count})`, true);
        else           showToast(fa ? `ℹ️ این توییت قبلاً در لیست بود (${res.count})` : `ℹ️ Already in list (${res.count})`, false);
      });
    } catch (err) {
      showToast(fa ? '⚠️ اکستنشن به‌روز شده، صفحه X را رفرش کنید' : '⚠️ Extension updated, please refresh this X tab', false);
    }
  }

  function currentStatusId() {
    return location.pathname.match(/\/status\/(\d+)/)?.[1] || null;
  }

  function onTweetClick(e) {
    if (!listModeOn || botModeCache === 'manual') return;
    if (e.button !== 0 && e.button !== 1) return; // left click + middle click (auxclick)
    const target = e.target;
    if (!(target instanceof Element)) return;
    if (target.closest('#' + PANEL_ID + ', #' + BTN_ID)) return;

    let url = null;
    const a = target.closest('a[href]');
    if (a) {
      url = normalizeTweetUrl(a.href);
    } else {
      // click on the blank area of a tweet card (X opens the tweet via JS, not a plain link)
      const article = target.closest('article[data-testid="tweet"]');
      const interactive = target.closest('button,[role="button"],[role="menuitem"],[role="group"],input,textarea,[contenteditable="true"],video,[data-testid="tweetPhoto"]');
      if (article && !interactive) {
        const timeLink = article.querySelector('a[href*="/status/"] time')?.closest('a');
        if (timeLink) {
          url = normalizeTweetUrl(timeLink.href);
          // do not hijack clicks on the tweet you are already viewing
          if (url && url.endsWith('/status/' + currentStatusId())) return;
        }
      }
    }
    if (!url) return;

    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    addToList(url);
  }
  // window + capture so we run before X's own handlers; auxclick = middle-click / open-in-new-tab
  window.addEventListener('click', onTweetClick, true);
  window.addEventListener('auxclick', onTweetClick, true);

  // ─── Own account / duplicate-reply detection ───────────────────────────────
  function detectOwnUsername() {
    if (cachedOwnUsername) return cachedOwnUsername;

    const switcher = document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"]');
    if (switcher) {
      const label = switcher.getAttribute('aria-label') || '';
      const m = label.match(/@([\w\d_]+)/);
      if (m) { cachedOwnUsername = m[1].toLowerCase(); return cachedOwnUsername; }
    }

    const profileLink = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
    if (profileLink) {
      const href = profileLink.getAttribute('href') || '';
      const m = href.match(/^\/([^/?#]+)/);
      if (m && m[1] !== 'home' && m[1] !== 'explore') {
        cachedOwnUsername = m[1].toLowerCase();
        return cachedOwnUsername;
      }
    }
    return null;
  }

  function alreadyRepliedInThread(ownUsername) {
    if (!ownUsername) return false;
    const articles = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));
    for (let i = 1; i < articles.length; i++) {
      const article = articles[i];
      const userLink = article.querySelector('a[role="link"][href^="/"]');
      if (userLink) {
        const href = userLink.getAttribute('href') || '';
        const m = href.match(/^\/([^/?#]+)/);
        if (m && m[1].toLowerCase() === ownUsername) return true;
      }
    }
    return false;
  }

  async function fillReplyBox(text) {
    const composer = document.querySelector('div[contenteditable="true"][role="textbox"]');
    if (!composer) return false;
    composer.focus();
    document.execCommand('insertText', false, text);
    return true;
  }

  async function autoLikeTweet() {
    if (document.querySelector('article [data-testid="unlike"]')) return false;
    const likeBtn = document.querySelector('article [data-testid="like"]');
    if (!likeBtn) return false;
    likeBtn.click();
    await sleep(350);
    return true;
  }

  async function onOpen(prefillText = '', isAuto = false) {
    ensureStyles();
    const panel = createPanel();
    const input = panel.querySelector('#fm-input');
    const output = panel.querySelector('#fm-output');
    const tone = panel.querySelector('#fm-tone');
    const gen = panel.querySelector('#fm-generate');
    const insert = panel.querySelector('#fm-insert');

    const tweetText = prefillText || getActiveTweetText() || '';
    input.value = tweetText;
    panel.classList.add('open');

    // reply tone: always load the saved one, and save when changed from the panel
    tone.onchange = () => chrome.storage.sync.set({ tone: tone.value });

    gen.onclick = () => {
      chrome.runtime.sendMessage(
        { type: 'GENERATE_REPLY', payload: { tweetText: input.value, tone: tone.value } },
        res => {
          if (res?.ok) {
            output.value = res.data;
            chrome.storage.sync.get(['autoSendReply', 'keepTabOpen', 'autoInsert'], async settings => {
              if (settings.autoInsert !== false) {
                await fillReplyBox(res.data);

                if (settings.autoSendReply || settings.keepTabOpen) {
                  await sleep(1000);
                  const sendBtn = document.querySelector('[data-testid="tweetButtonInline"]') || document.querySelector('[data-testid="tweetButton"]');
                  if (sendBtn) {
                    sendBtn.click();
                    if (!settings.keepTabOpen && settings.autoSendReply) {
                      setTimeout(() => chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId: ownTabId }), 2500);
                    }
                  }
                }
              }
            });
          }
        }
      );
    };

    insert.onclick = async () => {
      if (output.value) await fillReplyBox(output.value);
    };

    const data = await getSync(['tone', 'botMode', 'autoLike']);
    tone.value = data.tone || 'friendly';

    if (data.botMode === 'manual' && !isAuto) return;

    await sleep(1000);
    const username = detectOwnUsername();
    if (isAuto && username && alreadyRepliedInThread(username)) {
      setTimeout(() => chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId: ownTabId }), 1500);
      return;
    }

    if (data.autoLike && isAuto) {
      await sleep(500);
      await autoLikeTweet();
    }

    if (isAuto && tweetText.length > 3) {
      gen.click();
    }
  }

  function triggerAutoModeIfReady() {
    chrome.storage.sync.get(['botMode'], data => {
      if (data.botMode !== 'manual' && /(\/status\/|\/statuses\/)\d+/.test(location.pathname)) {
        let attempts = 0;
        const timer = setInterval(() => {
          attempts++;
          const text = getActiveTweetText();
          if (text) {
            clearInterval(timer);
            onOpen(text, true);
          } else if (attempts > 25) {
            clearInterval(timer);
          }
        }, 600);
      }
    });
  }

  let lastPath = location.pathname;
  setInterval(() => {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      triggerAutoModeIfReady();
    }
  }, 1000);

  function init() {
    ensureStyles();
    ensureButton();
    triggerAutoModeIfReady();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
