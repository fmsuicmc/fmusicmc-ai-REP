// background.js — v1.5.0 (fmusicmc)
import { chatReply, parseOwnProjects } from './lib/llm.js';

const STORAGE_DEFAULTS = {
  enabled: true,
  tone: 'friendly',
  translationStyle: 'friendly',
  useSearch: true,
  maxChars: 240,
  provider: 'openrouter',
  endpoint: 'https://openrouter.ai/api/v1/chat/completions',
  model: 'anthropic/claude-haiku-4-5',
  apiKey: '',
  ownProjects: '',
  autoInsert: true,
  autoCloseTab: true,
  autoSendReply: false,
  keepTabOpen: false,
  autoLike: false
};

function getSettings() {
  return new Promise(resolve => chrome.storage.sync.get(STORAGE_DEFAULTS, resolve));
}
const localGet = keys => new Promise(r => chrome.storage.local.get(keys, r));
const localSet = obj  => new Promise(r => chrome.storage.local.set(obj, r));

async function fetchFacts(query) {
  try {
    const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`;
    const res = await fetch(url);
    if (!res.ok) return '';
    const data = await res.json();
    return data?.extract ? data.extract.slice(0, 400) : '';
  } catch {
    return '';
  }
}

function extractEntities(text) {
  const hashtags  = [...text.matchAll(/#(\w+)/g)].map(m => '#' + m[1]);
  const cashtags  = [...text.matchAll(/\$([A-Za-z]+)/g)].map(m => '$' + m[1]);
  const mentions  = [...text.matchAll(/@(\w+)/g)].map(m => '@' + m[1]);
  const stop = new Set(['that','this','with','from','have','will','they','been','what','when','your','also','more','just','about','which','there','their','would','into','than','some','like','other','these','after','where']);
  const keywords = [...new Set(
    text.toLowerCase().match(/\b[a-z]{5,}\b/g)?.filter(w => !stop.has(w)) || []
  )].slice(0, 8);
  return { hashtags, cashtags, mentions, keywords };
}

// ─── Queue (single writer with a simple lock to avoid race conditions) ───────
let queueLock = Promise.resolve();
function withQueueLock(fn) {
  const p = queueLock.then(fn);
  queueLock = p.catch(() => {});
  return p;
}

let queueRunning = false;

function shiftQueue() {
  return withQueueLock(async () => {
    const data = await localGet(['tweetQueue']);
    const queue = data.tweetQueue || [];
    const next = queue.shift();
    await localSet({ tweetQueue: queue });
    return { next, left: queue.length };
  });
}

function addToQueue(url) {
  return withQueueLock(async () => {
    const data = await localGet(['tweetQueue']);
    const queue = data.tweetQueue || [];
    if (queue.includes(url)) return { added: false, count: queue.length };
    queue.push(url);
    await localSet({ tweetQueue: queue });
    return { added: true, count: queue.length };
  });
}

async function runQueue(intervalMs) {
  if (queueRunning) return;
  queueRunning = true;

  while (true) {
    const { next, left } = await shiftQueue();
    if (!next) break;

    try {
      await chrome.tabs.create({ url: next, active: true });
    } catch (err) {
      console.error('Tab create error:', err);
    }

    if (left === 0) {
      await localSet({ nextTweetTime: 0 });
      break;
    }

    const waitTime = intervalMs > 0 ? intervalMs : 6000;
    await localSet({ nextTweetTime: Date.now() + waitTime });
    await new Promise(resolve => setTimeout(resolve, waitTime));
  }
  queueRunning = false;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_TAB_ID') {
    sendResponse({ tabId: sender.tab?.id ?? null });
    return false;
  }

  if (msg.type === 'CLOSE_TAB') {
    const targetId = msg.tabId ?? sender.tab?.id ?? null;
    if (targetId) {
      chrome.tabs.remove(targetId);
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
        if (tabs[0]?.id) chrome.tabs.remove(tabs[0].id);
      });
    }
    return false;
  }

  if (msg.type === 'ADD_TO_QUEUE') {
    addToQueue(msg.url).then(r => sendResponse({ ok: true, ...r }));
    return true;
  }

  if (msg.type === 'START_TWEET_QUEUE') {
    const { urls, intervalMinutes } = msg.payload;
    const intervalMs = (intervalMinutes || 0) * 60 * 1000;

    queueRunning = false;
    withQueueLock(() => localSet({ tweetQueue: urls })).then(() => {
      sendResponse({ ok: true });
      runQueue(intervalMs);
    });
    return true;
  }

  if (msg.type === 'GENERATE_REPLY' || msg.type === 'AUTO_GENERATE') {
    (async () => {
      try {
        const settings = await getSettings();
        const { tweetText, tone, useSearch } = msg.payload;
        const maxChars     = settings.maxChars || 240;
        const ownProjects  = parseOwnProjects(settings.ownProjects || '');
        const translationStyle = settings.translationStyle || 'friendly';
        const entities     = extractEntities(tweetText);

        let facts = '';
        if ((useSearch ?? settings.useSearch) && entities.keywords.length > 0) {
          facts = await fetchFacts(entities.keywords[0]);
        }

        const reply = await chatReply(
          { tweetText, tone: tone || settings.tone, maxChars, facts, entities, ownProjects, translationStyle },
          { endpoint: settings.endpoint, model: settings.model, apiKey: settings.apiKey }
        );

        if (msg.type === 'AUTO_GENERATE') {
          sendResponse({
            ok: true,
            data: reply,
            autoInsert:     settings.autoInsert,
            autoCloseTab:   settings.autoCloseTab,
            autoSendReply:  settings.autoSendReply,
            keepTabOpen:    settings.keepTabOpen,
            autoLike:       settings.autoLike
          });
        } else {
          sendResponse({ ok: true, data: reply });
        }
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  }
});
