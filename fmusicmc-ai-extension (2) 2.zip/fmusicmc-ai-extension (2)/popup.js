// popup.js — v2.0
const autoSendToggle        = document.getElementById('autoSendReply');
const keepTabOpenToggle     = document.getElementById('keepTabOpen');
const autoLikeToggle        = document.getElementById('autoLike');
const autoSettingsContainer = document.getElementById('autoSettingsContainer');
const openPanelBtn          = document.getElementById('openPanel');
const startBatchBtn         = document.getElementById('startBatchBtn');
const clearQueueBtn         = document.getElementById('clearQueueBtn');
const tweetListInput        = document.getElementById('tweetListInput');
const timerIntervalSelect   = document.getElementById('timerInterval');
const queueCountEl          = document.getElementById('queueCount');
const timerDisplayEl        = document.getElementById('timerDisplay');
const pinSidebarBtn         = document.getElementById('pinSidebarBtn');
const statusEl              = document.getElementById('status');
const replyToneSelect       = document.getElementById('replyTone');
const listModeToggle        = document.getElementById('listMode');
const batchSection          = document.getElementById('batchSection');
const addToListBtn          = document.getElementById('addToListBtn');
const maxCharsInput         = document.getElementById('maxChars');
const saveAllBtn            = document.getElementById('saveAllBtn');

let countdownInterval = null;
let targetTimestamp = null;

const i18n = {
  fa: {
    title: 'fmusicmc ai Pro', subtitle: 'کنترل پنل هوشمند توییت‌ها',
    pin_btn: '📌 پین کردن به عنوان سایدبار مرورگر',
    sec_mode: 'انتخاب حالت اجرا', mode_auto: '⚡ حالت خودکار', mode_manual: '✋ حالت تمام‌دستی',
    sec_auto_settings: 'تنظیمات پیشرفته خودکار',
    lbl_autosend: 'ارسال و بستن خودکار تب', sub_autosend: 'ارسال ریپلای + بستن تب',
    lbl_keeptab: 'ارسال ولی بسته نشدن تب', sub_keeptab: 'ریپلای ارسال شود اما تب باز بماند',
    lbl_autolike: '❤️ لایک خودکار توییت', sub_autolike: 'لایک کردن هنگام ورود',
    sec_batch: 'پردازش دسته‌ای توییت‌ها و ثانیه‌شمار',
    lbl_timer: 'فاصله زمانی بین هر توییت:',
    btn_batch: '🚀 شروع صف هوشمند توییت‌ها',
    btn_open: '⚡ باز کردن پنل روی تب فعلی X',
    link_settings: '⚙️ تنظیمات کامل و API Key',
    err_empty: '❌ لطفاً لینک توییت‌ها را وارد کنید',
    err_no_url: '❌ هیچ لینک معتبر توییتی یافت نشد',
    msg_auto: '⚡ حالت خودکار فعال شد',
    msg_manual: '✋ حالت تمام‌دستی فعال شد (بدون اتومیشن)',
    msg_started: '✅ صف توییت‌ها با موفقیت استارت شد',
    msg_cleared: '🗑️ صف توییت‌ها پاک و ریست شد',
    sec_tone: 'حالت پاسخ‌دهی',
    tone_friendly: 'دوستانه', tone_professional: 'حرفه‌ای', tone_witty: 'طنز ملایم', tone_analytical: 'تحلیلی', tone_neutral: 'خنثی',
    lbl_listmode: '📋 حالت لیست', sub_listmode: 'کلیک روی هر توییت در X آن را به لیست اضافه می‌کند',
    btn_add_list: '➕ افزودن لینک‌ها به لیست',
    msg_list_on: '📋 حالت لیست روشن شد: روی هر توییت کلیک کنید تا به لیست برود',
    msg_list_off: '📋 حالت لیست خاموش شد: توییت‌ها عادی باز می‌شوند',
    msg_added: '✅ لینک‌ها به لیست اضافه شد',
    msg_tone: '🎭 حالت پاسخ‌دهی ذخیره شد',
    sec_chars: 'حداکثر کاراکتر پاسخ', btn_save_all: '💾 ذخیره همه تنظیمات', msg_saved_all: '✅ همه تنظیمات ذخیره شد',
    lbl_remaining: 'باقی‌مانده:', lbl_next: 'بعدی در:', btn_clear: '🗑️ پاک کردن صف'
  },
  en: {
    title: 'fmusicmc ai Pro', subtitle: 'Smart Tweet Control Panel',
    pin_btn: '📌 Pin as Browser Sidebar',
    sec_mode: 'Execution Mode', mode_auto: '⚡ Auto Mode', mode_manual: '✋ Full Manual Mode',
    sec_auto_settings: 'Advanced Auto Settings',
    lbl_autosend: 'Auto-send & close tab', sub_autosend: 'Send reply + close tab',
    lbl_keeptab: 'Send without closing tab', sub_keeptab: 'Reply sent but tab remains open',
    lbl_autolike: '❤️ Auto-like tweet', sub_autolike: 'Likes tweet upon opening',
    sec_batch: 'Batch Tweet Queue & Countdown',
    lbl_timer: 'Interval between tweets:',
    btn_batch: '🚀 Start Smart Tweet Queue',
    btn_open: '⚡ Open panel on current X tab',
    link_settings: '⚙️ Full Settings & API Key',
    err_empty: '❌ Please enter tweet links',
    err_no_url: '❌ No valid tweet links found',
    msg_auto: '⚡ Auto mode activated',
    msg_manual: '✋ Manual mode activated (No automation)',
    msg_started: '✅ Tweet queue successfully started',
    msg_cleared: '🗑️ Tweet queue cleared and reset',
    sec_tone: 'Reply Tone',
    tone_friendly: 'Friendly', tone_professional: 'Professional', tone_witty: 'Witty', tone_analytical: 'Analytical', tone_neutral: 'Neutral',
    lbl_listmode: '📋 List Mode', sub_listmode: 'Clicking any tweet on X adds it to the list',
    btn_add_list: '➕ Add links to list',
    msg_list_on: '📋 List mode on: click any tweet to add it to the list',
    msg_list_off: '📋 List mode off: tweets open normally',
    msg_added: '✅ Links added to list',
    msg_tone: '🎭 Reply tone saved',
    sec_chars: 'Max reply characters', btn_save_all: '💾 Save all settings', msg_saved_all: '✅ All settings saved',
    lbl_remaining: 'Remaining:', lbl_next: 'Next in:', btn_clear: '🗑️ Clear queue'
  }
};

function applyPopupLang(lang) {
  const t = i18n[lang] || i18n.fa;
  document.getElementById('ui_title').textContent = t.title;
  document.getElementById('ui_subtitle').textContent = t.subtitle;
  pinSidebarBtn.textContent = t.pin_btn;
  document.getElementById('ui_sec_mode').textContent = t.sec_mode;
  document.getElementById('ui_mode_auto').textContent = t.mode_auto;
  document.getElementById('ui_mode_manual').textContent = t.mode_manual;
  document.getElementById('ui_sec_auto_settings').textContent = t.sec_auto_settings;
  document.getElementById('ui_lbl_autosend').textContent = t.lbl_autosend;
  document.getElementById('ui_sub_autosend').textContent = t.sub_autosend;
  document.getElementById('ui_lbl_keeptab').textContent = t.lbl_keeptab;
  document.getElementById('ui_sub_keeptab').textContent = t.sub_keeptab;
  document.getElementById('ui_lbl_autolike').textContent = t.lbl_autolike;
  document.getElementById('ui_sub_autolike').textContent = t.sub_autolike;
  document.getElementById('ui_sec_batch').textContent = t.sec_batch;
  document.getElementById('ui_lbl_timer').textContent = t.lbl_timer;
  document.getElementById('startBatchBtn').textContent = t.btn_batch;
  document.getElementById('openPanel').textContent = t.btn_open;
  document.getElementById('ui_link_settings').textContent = t.link_settings;
  document.getElementById('ui_sec_tone').textContent = t.sec_tone;
  document.getElementById('ui_sec_chars').textContent = t.sec_chars;
  saveAllBtn.textContent = t.btn_save_all;
  document.getElementById('ui_lbl_listmode').textContent = t.lbl_listmode;
  document.getElementById('ui_sub_listmode').textContent = t.sub_listmode;
  addToListBtn.textContent = t.btn_add_list;
  clearQueueBtn.textContent = t.btn_clear;
  document.querySelectorAll('[data-i18n]').forEach(el => { if (t[el.dataset.i18n]) el.textContent = t[el.dataset.i18n]; });
  const qbox = document.getElementById('queueStatusBox');
  qbox.children[0].firstChild.textContent = t.lbl_remaining + ' ';
  qbox.children[2].firstChild.textContent = t.lbl_next + ' ';
  document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
  document.documentElement.lang = lang;
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === lang));
}

pinSidebarBtn.addEventListener('click', () => {
  if (chrome.sidePanel && chrome.sidePanel.open) {
    chrome.windows.getCurrent(window => {
      chrome.sidePanel.open({ windowId: window.id }, () => {});
    });
  } else {
    alert('سایدبار در این نسخه مرورگر پشتیبانی نمی‌شود.');
  }
});

function updateQueueState() {
  chrome.storage.local.get(['tweetQueue', 'nextTweetTime'], data => {
    const queue = data.tweetQueue || [];
    queueCountEl.textContent = queue.length;
    targetTimestamp = data.nextTweetTime || 0;
  });
}

function startCountdownTimer() {
  if (countdownInterval) clearInterval(countdownInterval);

  countdownInterval = setInterval(() => {
    updateQueueState();
    if (!targetTimestamp || Date.now() >= targetTimestamp) {
      timerDisplayEl.textContent = '00:00';
      return;
    }

    const diff = Math.floor((targetTimestamp - Date.now()) / 1000);
    const mins = Math.floor(diff / 60).toString().padStart(2, '0');
    const secs = (diff % 60).toString().padStart(2, '0');
    timerDisplayEl.textContent = `${mins}:${secs}`;
  }, 1000);
}

setInterval(updateQueueState, 1000);

document.querySelectorAll('.lang-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const lang = btn.dataset.lang;
    applyPopupLang(lang);
    chrome.storage.sync.set({ popupLang: lang });
  });
});

function updateBatchVisibility() {
  batchSection.classList.toggle('hidden', !listModeToggle.checked);
}

function updateModeUI(mode) {
  document.querySelectorAll('.mode-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.mode === mode);
  });
  autoSettingsContainer.classList.toggle('hidden', mode === 'manual');
}

chrome.storage.sync.get(['autoSendReply', 'keepTabOpen', 'autoLike', 'botMode', 'popupLang', 'tone', 'listMode', 'maxChars'], (data) => {
  if (data.autoSendReply !== undefined) autoSendToggle.checked = !!data.autoSendReply;
  if (data.keepTabOpen !== undefined) keepTabOpenToggle.checked = !!data.keepTabOpen;
  if (data.autoLike    !== undefined) autoLikeToggle.checked    = !!data.autoLike;
  replyToneSelect.value = data.tone || 'friendly';
  maxCharsInput.value = data.maxChars || 240;
  listModeToggle.checked = !!data.listMode;
  updateBatchVisibility();
  const mode = data.botMode || 'auto';
  updateModeUI(mode);
  applyPopupLang(data.popupLang || 'fa');
  updateQueueState();
  startCountdownTimer();
});

document.querySelectorAll('.mode-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const mode = btn.dataset.mode;
    updateModeUI(mode);
    chrome.storage.sync.set({ botMode: mode, enabled: mode === 'auto' });
    const lang = document.documentElement.lang || 'fa';
    showStatus(mode === 'auto' ? i18n[lang].msg_auto : i18n[lang].msg_manual, 'ok');
  });
});

autoSendToggle.addEventListener('change', () => {
  chrome.storage.sync.set({ autoSendReply: autoSendToggle.checked });
  if (autoSendToggle.checked && keepTabOpenToggle.checked) {
    keepTabOpenToggle.checked = false;
    chrome.storage.sync.set({ keepTabOpen: false });
  }
});

keepTabOpenToggle.addEventListener('change', () => {
  chrome.storage.sync.set({ keepTabOpen: keepTabOpenToggle.checked });
  if (keepTabOpenToggle.checked && autoSendToggle.checked) {
    autoSendToggle.checked = false;
    chrome.storage.sync.set({ autoSendReply: false });
  }
});

autoLikeToggle.addEventListener('change', () => chrome.storage.sync.set({ autoLike: autoLikeToggle.checked }));

// حالت پاسخ‌دهی (تون): ذخیره می‌شود و مستقیم روی تولید پاسخ اعمال می‌شود
replyToneSelect.addEventListener('change', () => {
  const lang = document.documentElement.lang || 'fa';
  chrome.storage.sync.set({ tone: replyToneSelect.value });
  showStatus(i18n[lang].msg_tone, 'ok');
});

// اگر تون از جای دیگر (پنل روی X یا صفحه تنظیمات) عوض شد، اینجا هم به‌روز شود
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync' && changes.tone?.newValue) replyToneSelect.value = changes.tone.newValue;
});

function clampChars() {
  let v = parseInt(maxCharsInput.value, 10);
  if (isNaN(v)) v = 240;
  v = Math.min(280, Math.max(40, v));
  maxCharsInput.value = v;
  return v;
}
maxCharsInput.addEventListener('change', () => chrome.storage.sync.set({ maxChars: clampChars() }));

// دکمه ذخیره کلی: همه تنظیمات پاپ‌آپ را یکجا ذخیره می‌کند
saveAllBtn.addEventListener('click', () => {
  const lang = document.documentElement.lang || 'fa';
  const mode = document.querySelector('.mode-btn.active')?.dataset.mode || 'auto';
  chrome.storage.sync.set({
    botMode: mode,
    enabled: mode === 'auto',
    tone: replyToneSelect.value,
    maxChars: clampChars(),
    autoSendReply: autoSendToggle.checked,
    keepTabOpen: keepTabOpenToggle.checked,
    autoLike: autoLikeToggle.checked,
    listMode: listModeToggle.checked,
    popupLang: lang
  }, () => showStatus(i18n[lang].msg_saved_all, 'ok'));
});

// حالت لیست روشن/خاموش
listModeToggle.addEventListener('change', () => {
  const lang = document.documentElement.lang || 'fa';
  chrome.storage.sync.set({ listMode: listModeToggle.checked });
  updateBatchVisibility();
  showStatus(listModeToggle.checked ? i18n[lang].msg_list_on : i18n[lang].msg_list_off, 'ok');
});

// استخراج و یکدست‌سازی لینک‌های توییت از متن
function extractUrls(rawText) {
  const found = rawText.match(/https?:\/\/(?:www\.)?(?:x|twitter)\.com\/[^\s]+/g) || [];
  const norm = found.map(u => {
    const m = u.match(/^https?:\/\/(?:www\.)?(?:x|twitter)\.com\/([^/\s?#]+)\/status\/(\d+)/);
    return m ? `https://x.com/${m[1]}/status/${m[2]}` : u;
  });
  return [...new Set(norm)];
}

function getStoredQueue() {
  return new Promise(resolve => chrome.storage.local.get(['tweetQueue'], d => resolve(d.tweetQueue || [])));
}

// افزودن دستی لینک‌ها به لیست (بدون شروع)
addToListBtn.addEventListener('click', async () => {
  const lang = document.documentElement.lang || 'fa';
  const rawText = tweetListInput.value.trim();
  if (!rawText) { showStatus(i18n[lang].err_empty, 'err'); return; }
  const urls = extractUrls(rawText);
  if (urls.length === 0) { showStatus(i18n[lang].err_no_url, 'err'); return; }
  const merged = [...new Set([...(await getStoredQueue()), ...urls])];
  chrome.storage.local.set({ tweetQueue: merged }, () => {
    tweetListInput.value = '';
    updateQueueState();
    showStatus(i18n[lang].msg_added, 'ok');
  });
});

// دکمه پاک کردن کل صف و ریست شمارنده
clearQueueBtn.addEventListener('click', () => {
  const lang = document.documentElement.lang || 'fa';
  chrome.storage.local.set({ tweetQueue: [], nextTweetTime: 0 }, () => {
    updateQueueState();
    showStatus(i18n[lang].msg_cleared, 'ok');
  });
});

startBatchBtn.addEventListener('click', async () => {
  const lang = document.documentElement.lang || 'fa';
  const rawText = tweetListInput.value.trim();
  const typedUrls = rawText ? extractUrls(rawText) : [];
  const stored = await getStoredQueue();

  if (!rawText && stored.length === 0) { showStatus(i18n[lang].err_empty, 'err'); return; }
  if (rawText && typedUrls.length === 0 && stored.length === 0) { showStatus(i18n[lang].err_no_url, 'err'); return; }

  // لینک‌های ذخیره‌شده در لیست + لینک‌هایی که الان نوشته شده
  const urls = [...new Set([...stored, ...typedUrls])];

  const intervalMinutes = parseFloat(timerIntervalSelect.value || '0');
  const delayMs = intervalMinutes * 60 * 1000;
  targetTimestamp = Date.now() + delayMs;

  chrome.storage.local.set({ nextTweetTime: targetTimestamp }, () => {
    chrome.runtime.sendMessage({ type: 'START_TWEET_QUEUE', payload: { urls, intervalMinutes } }, res => {
      if (res?.ok) {
        showStatus(i18n[lang].msg_started, 'ok');
        tweetListInput.value = '';
        updateQueueState();
      }
    });
  });
});

openPanelBtn.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab?.url?.match(/x\.com|twitter\.com/)) {
      showStatus('❌ لطفاً در صفحه X/Twitter باشید', 'err');
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { document.getElementById('fmusicmc-ai-btn')?.click(); }
    });
    window.close();
  });
});

function showStatus(msg, type) {
  statusEl.textContent = msg;
  statusEl.className   = 'status ' + type;
  setTimeout(() => { statusEl.className = 'status'; }, 3500);
}