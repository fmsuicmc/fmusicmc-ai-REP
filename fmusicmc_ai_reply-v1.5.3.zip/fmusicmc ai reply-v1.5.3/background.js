// background.js — v1.1 (fmusicmc)
import { chatReply, parseOwnProjects, detectOwnInTweet } from './lib/llm.js';

const STORAGE_DEFAULTS = {
  enabled: true,
  tone: 'friendly',
  translationStyle: 'friendly',
  useSearch: true,
  maxChars: 240,
  provider: 'openrouter',
  endpoint: 'https://openrouter.ai/api/v1/chat/completions',
  model: 'anthropic/claude-haiku-4-5',
  apiKey: '',
  ownProjects: '',   // user sets their own — no pre-filled list
  autoInsert: true,
  autoCloseTab: true,
  autoSendReply: false,
  autoLike: false
};

function getSettings() {
  return new Promise(resolve => chrome.storage.sync.get(STORAGE_DEFAULTS, resolve));
}

async function fetchFacts(query) {
  try {
    const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`;
    const res = await fetch(url);
    if (!res.ok) return '';
    const data = await res.json();
    return data?.extract ? data.extract.slice(0, 400) : '';
  } catch {
    return '';
  }
}

function extractEntities(text) {
  const hashtags  = [...text.matchAll(/#(\w+)/g)].map(m => '#' + m[1]);
  const cashtags  = [...text.matchAll(/\$([A-Za-z]+)/g)].map(m => '$' + m[1]);
  const mentions  = [...text.matchAll(/@(\w+)/g)].map(m => '@' + m[1]);
  const stop = new Set(['that','this','with','from','have','will','they','been','what','when','your','also','more','just','about','which','there','their','would','into','than','some','like','other','these','after','where']);
  const keywords = [...new Set(
    text.toLowerCase().match(/\b[a-z]{5,}\b/g)?.filter(w => !stop.has(w)) || []
  )].slice(0, 8);
  return { hashtags, cashtags, mentions, keywords };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // ── Return the sender's own tab ID ────────────────────────────────────────
  if (msg.type === 'GET_TAB_ID') {
    sendResponse({ tabId: sender.tab?.id ?? null });
    return false;
  }

  // ── Close a specific tab (or active tab as fallback) ──────────────────────
  if (msg.type === 'CLOSE_TAB') {
    const targetId = msg.tabId ?? sender.tab?.id ?? null;
    if (targetId) {
      chrome.tabs.remove(targetId);
    } else {
      // Fallback: close active tab in current window
      chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
        if (tabs[0]?.id) chrome.tabs.remove(tabs[0].id);
      });
    }
    return false;
  }

  // ── Manual generate ────────────────────────────────────────────────────────
  if (msg.type === 'GENERATE_REPLY') {
    (async () => {
      try {
        const settings = await getSettings();
        const { tweetText, tone, useSearch } = msg.payload;
        const maxChars     = settings.maxChars || 240;
        const ownProjects  = parseOwnProjects(settings.ownProjects || '');
        const translationStyle = settings.translationStyle || 'friendly';
        const entities     = extractEntities(tweetText);

        let facts = '';
        if (useSearch && entities.keywords.length > 0) {
          facts = await fetchFacts(entities.keywords[0]);
        }

        const reply = await chatReply(
          { tweetText, tone: tone || settings.tone, maxChars, facts, entities, ownProjects, translationStyle },
          { endpoint: settings.endpoint, model: settings.model, apiKey: settings.apiKey }
        );
        sendResponse({ ok: true, data: reply });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  }

  // ── Auto-generate on tweet open ────────────────────────────────────────────
  if (msg.type === 'AUTO_GENERATE') {
    (async () => {
      try {
        const settings = await getSettings();
        if (!settings.enabled || !settings.apiKey) {
          sendResponse({ ok: false, skip: true });
          return;
        }
        const { tweetText } = msg.payload;
        const maxChars     = settings.maxChars || 240;
        const ownProjects  = parseOwnProjects(settings.ownProjects || '');
        const translationStyle = settings.translationStyle || 'friendly';
        const entities     = extractEntities(tweetText);

        let facts = '';
        if (settings.useSearch && entities.keywords.length > 0) {
          facts = await fetchFacts(entities.keywords[0]);
        }

        const reply = await chatReply(
          { tweetText, tone: settings.tone, maxChars, facts, entities, ownProjects, translationStyle },
          { endpoint: settings.endpoint, model: settings.model, apiKey: settings.apiKey }
        );
        sendResponse({
          ok: true,
          data: reply,
          autoInsert:     settings.autoInsert,
          autoCloseTab:   settings.autoCloseTab,
          autoSendReply:  settings.autoSendReply,
          autoLike:       settings.autoLike
        });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  }
});
