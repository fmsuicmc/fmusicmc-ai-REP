// content.js — v1.5.3 (fmusicmc)
// Fix: if already replied in thread → close tab silently (auto mode) or show warning (manual mode)
// Never generate/insert/send if prior reply detected in DOM or sessionStorage
// Fix v1.5.3: tone dropdown change in panel now persists to storage
(function () {
  const STYLE_ID = 'fmusicmc-ai-style';
  const BTN_ID   = 'fmusicmc-ai-btn';
  const PANEL_ID = 'fmusicmc-ai-panel';

  // ── Per-tab state ──────────────────────────────────────────────────────────
  let currentProcessingUrl = '';
  let autoGenInProgress    = false;
  let replyWatchActive     = false;
  let ownTabId             = null;
  let cachedOwnUsername    = null;

  // ── Resolve own tab ID once ───────────────────────────────────────────────
  chrome.runtime.sendMessage({ type: 'GET_TAB_ID' }, res => {
    if (res?.tabId) ownTabId = res.tabId;
  });

  // ────────────────────────────────────────────────────────────────────────────
  // OWN USERNAME DETECTION
  // ────────────────────────────────────────────────────────────────────────────
  function detectOwnUsername() {
    if (cachedOwnUsername) return cachedOwnUsername;

    const switcher = document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"]');
    if (switcher) {
      const label = switcher.getAttribute('aria-label') || '';
      const m = label.match(/@([\w\d_]+)/);
      if (m) { cachedOwnUsername = m[1].toLowerCase(); return cachedOwnUsername; }
    }

    const profileLink = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
    if (profileLink) {
      const href = profileLink.getAttribute('href') || '';
      const m = href.match(/^\/([^/?#]+)/);
      if (m && m[1] !== 'home' && m[1] !== 'explore') {
        cachedOwnUsername = m[1].toLowerCase();
        return cachedOwnUsername;
      }
    }

    const avatarImgs = document.querySelectorAll('nav img[alt]');
    for (const img of avatarImgs) {
      const alt = img.getAttribute('alt') || '';
      const m = alt.match(/@?([\w\d_]{1,50})/);
      if (m) { cachedOwnUsername = m[1].toLowerCase(); return cachedOwnUsername; }
    }

    return null;
  }

  // ────────────────────────────────────────────────────────────────────────────
  // CHECK IF USER ALREADY REPLIED IN THIS THREAD
  // ────────────────────────────────────────────────────────────────────────────
  function alreadyRepliedInThread(ownUsername) {
    if (!ownUsername) return false;

    const articles = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));
    for (let i = 1; i < articles.length; i++) {
      const article = articles[i];

      const userLink = article.querySelector('a[role="link"][href^="/"]');
      if (userLink) {
        const href = userLink.getAttribute('href') || '';
        const m = href.match(/^\/([^/?#]+)/);
        if (m && m[1].toLowerCase() === ownUsername) return true;
      }

      const userSpan = article.querySelector('[data-testid="User-Name"]');
      if (userSpan) {
        const text = userSpan.textContent || '';
        if (text.toLowerCase().includes('@' + ownUsername)) return true;
      }
    }
    return false;
  }

  // ── sessionStorage dedup ──────────────────────────────────────────────────
  function ssKey(url) { return 'fm_done_' + url.replace(/[^a-z0-9]/gi, '_'); }
  function markDone(url) { try { sessionStorage.setItem(ssKey(url), '1'); } catch {} }
  function alreadyDoneSession(url) {
    try { return sessionStorage.getItem(ssKey(url)) === '1'; } catch { return false; }
  }

  // ── Styles ─────────────────────────────────────────────────────────────────
  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const link = document.createElement('link');
    link.id   = STYLE_ID;
    link.rel  = 'stylesheet';
    link.href = chrome.runtime.getURL('styles/overlay.css');
    document.documentElement.appendChild(link);
  }

  // ── Auto-like (skip if already liked) ─────────────────────────────────────
  async function autoLikeTweet() {
    if (document.querySelector('article [data-testid="unlike"]')) return false;
    const likeBtn = document.querySelector('article [data-testid="like"]');
    if (!likeBtn) return false;
    likeBtn.click();
    await sleep(350);
    return true;
  }

  // ── Panel ──────────────────────────────────────────────────────────────────
  function createPanel() {
    let panel = document.getElementById(PANEL_ID);
    if (panel) return panel;

    panel = document.createElement('div');
    panel.id        = PANEL_ID;
    panel.className = 'fm-overlay';
    panel.innerHTML = `
      <div class="fm-header">
        <img src="${chrome.runtime.getURL('icons/icon128.png')}" class="fm-logo" alt="fmusicmc">
        <div class="fm-title">fmusicmc ai</div>
        <div class="fm-style-pills">
          <button class="fm-pill active" data-style="friendly">😊 Friendly</button>
          <button class="fm-pill" data-style="formal">🎩 Formal</button>
        </div>
        <button class="fm-close" aria-label="Close">×</button>
      </div>
      <div class="fm-body">
        <textarea id="fm-input" class="fm-text" placeholder="Tweet text detected here…"></textarea>
        <div class="fm-controls">
          <label>Tone:</label>
          <select id="fm-tone">
            <option value="friendly">Friendly / دوستانه</option>
            <option value="professional">Professional / حرفه‌ای</option>
            <option value="witty">Witty / طنز</option>
            <option value="analytical">Analytical / تحلیلی</option>
            <option value="neutral">Neutral / خنثی</option>
          </select>
          <label class="fm-check"><input type="checkbox" id="fm-search" checked> Search</label>
          <button id="fm-generate" class="fm-primary">⚡ Generate</button>
        </div>
        <div class="fm-output-wrap">
          <textarea id="fm-output" class="fm-text fm-output-text" placeholder="Generated reply appears here…" readonly></textarea>
          <div class="fm-char-count" id="fm-char-count">0 / 240</div>
        </div>
        <div class="fm-actions">
          <button id="fm-insert"     class="fm-secondary">⬆️ Insert in reply box</button>
          <button id="fm-send-close" class="fm-primary" style="display:none">🚀 Send &amp; Close tab</button>
          <button id="fm-copy"       class="fm-ghost">📋 Copy</button>
        </div>
        <div class="fm-status" id="fm-status"></div>
      </div>
    `;
    document.body.appendChild(panel);

    panel.querySelectorAll('.fm-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        panel.querySelectorAll('.fm-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        panel.dataset.style = btn.dataset.style;
        chrome.storage.sync.set({ translationStyle: btn.dataset.style });
      });
    });
    panel.querySelector('.fm-close')?.addEventListener('click', () => panel.classList.remove('open'));
    panel.addEventListener('keydown', e => { if (e.key === 'Escape') panel.classList.remove('open'); });

    chrome.storage.sync.get(['translationStyle'], data => {
      const s = data.translationStyle || 'friendly';
      panel.dataset.style = s;
      panel.querySelectorAll('.fm-pill').forEach(b => b.classList.toggle('active', b.dataset.style === s));
    });

    return panel;
  }

  // ── FAB button ─────────────────────────────────────────────────────────────
  function ensureButton() {
    if (document.getElementById(BTN_ID)) return;
    const btn = document.createElement('button');
    btn.id        = BTN_ID;
    btn.className = 'fm-fab';
    btn.title     = 'Smart Reply — fmusicmc ai';
    btn.innerHTML = `<img src="${chrome.runtime.getURL('icons/icon128.png')}" style="width:20px;height:20px;border-radius:50%;vertical-align:middle;margin-left:6px;"> fmusicmc ai`;
    btn.addEventListener('click', () => onOpen());
    document.body.appendChild(btn);
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function showStatus(panel, msg, type = 'info') {
    const el = panel?.querySelector('#fm-status');
    if (!el) return;
    el.textContent = msg;
    el.className   = 'fm-status fm-status-' + type;
    if (type !== 'loading') setTimeout(() => { el.textContent = ''; el.className = 'fm-status'; }, 3500);
  }

  function getActiveTweetText() {
    const detail = document.querySelector('article [data-testid="tweetText"]');
    if (detail?.innerText?.trim()) return detail.innerText.trim();
    for (const a of Array.from(document.querySelectorAll('article'))) {
      const box = a.getBoundingClientRect();
      if (box.bottom > 120 && box.top < window.innerHeight - 120) {
        const t = a.querySelector('[data-testid="tweetText"]');
        if (t?.innerText?.trim()) return t.innerText.trim();
      }
    }
    return window.getSelection()?.toString().trim() || '';
  }

  function getReplyBox() {
    for (const sel of [
      'div[data-testid="tweetTextarea_0"] div[contenteditable="true"]',
      'div[contenteditable="true"][data-testid="tweetTextarea_0"]',
      'div[contenteditable="true"][role="textbox"]',
      'div[contenteditable="true"]'
    ]) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  async function fillReplyBox(text) {
    const composer = getReplyBox();
    if (!composer) return false;
    composer.focus();
    composer.click();
    await sleep(150);
    try {
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, text);
      return true;
    } catch {
      try {
        await navigator.clipboard.writeText(text);
        document.execCommand('selectAll', false, null);
        document.execCommand('paste');
        return true;
      } catch {
        composer.textContent = text;
        composer.dispatchEvent(new InputEvent('input', { bubbles: true }));
        return true;
      }
    }
  }

  function clickTwitterSendBtn() {
    for (const sel of ['[data-testid="tweetButtonInline"]', '[data-testid="tweetButton"]']) {
      const btn = document.querySelector(sel);
      if (btn && !btn.disabled) { btn.click(); return true; }
    }
    return false;
  }

  // ── Auto-close watcher ─────────────────────────────────────────────────────
  function watchForReplySent(tabId, url) {
    if (replyWatchActive) return;
    replyWatchActive = true;
    const tryAttach = (attempts = 0) => {
      for (const sel of ['[data-testid="tweetButtonInline"]', '[data-testid="tweetButton"]']) {
        const btn = document.querySelector(sel);
        if (btn && !btn.dataset.fmWatched) {
          btn.dataset.fmWatched = '1';
          btn.addEventListener('click', () => {
            markDone(url);
            sleep(1800).then(() => chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId }));
          }, { once: true });
          return;
        }
      }
      if (attempts < 30) setTimeout(() => tryAttach(attempts + 1), 200);
    };
    tryAttach();
  }

  // ── Post-generate flow: insert → like → send → close ─────────────────────
  async function handlePostGenerate(panel, text, settings) {
    const { autoInsert, autoSendReply, autoCloseTab, autoLike, skipLike } = settings;
    const url = location.href;

    if (autoInsert || autoSendReply) {
      await sleep(400);
      if (!await fillReplyBox(text)) {
        showStatus(panel, '⚠️ Could not insert — copy manually.', 'warn');
        return;
      }
    }

    if (autoLike && !skipLike) {
      await sleep(300);
      await autoLikeTweet();
    }

    if (autoSendReply) {
      await sleep(600);
      const sent = clickTwitterSendBtn();
      if (sent) {
        markDone(url);
        showStatus(panel, '🚀 Sent! Closing tab…', 'ok');
        sleep(1800).then(() => chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId: ownTabId }));
      } else {
        showStatus(panel, '⚠️ Inserted — Send button not found. Send manually.', 'warn');
        if (autoCloseTab) watchForReplySent(ownTabId, url);
      }
    } else if (autoCloseTab) {
      showStatus(panel, autoLike ? '❤️ Liked! Click Send & tab closes.' : '✅ Inserted — click Send & tab closes!', 'ok');
      watchForReplySent(ownTabId, url);
    } else {
      showStatus(panel, autoLike ? '❤️ Liked & inserted!' : '✅ Inserted in reply box!', 'ok');
    }
  }

  // ── Check skip conditions — returns 'session' | 'replied' | null ──────────
  async function checkSkipReasons(url) {
    if (alreadyDoneSession(url)) return 'session';
    await sleep(600);
    const username = detectOwnUsername();
    if (username && alreadyRepliedInThread(username)) return 'replied';
    return null;
  }

  // ── Main open function ─────────────────────────────────────────────────────
  async function onOpen(prefillText = '', autoGenerate = false) {
    ensureStyles();
    const url = location.href;

    // ── AUTO MODE: close tab silently if already replied ──────────────────
    if (autoGenerate) {
      const skipReason = await checkSkipReasons(url);
      if (skipReason) {
        chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId: ownTabId });
        return;
      }
    }

    // ── MANUAL MODE: warn user if already replied, but still open panel ───
    // (user clicked FAB themselves — respect their intent, just warn them)
    const panel     = createPanel();
    const input     = panel.querySelector('#fm-input');
    const output    = panel.querySelector('#fm-output');
    const tone      = panel.querySelector('#fm-tone');
    const useSearch = panel.querySelector('#fm-search');
    const gen       = panel.querySelector('#fm-generate');
    const insert    = panel.querySelector('#fm-insert');
    const sendClose = panel.querySelector('#fm-send-close');
    const copyBtn   = panel.querySelector('#fm-copy');
    const charCount = panel.querySelector('#fm-char-count');

    const tweetText = prefillText || getActiveTweetText() || 'Tweet text not found. Replace manually.';
    input.value           = tweetText;
    output.value          = '';
    charCount.textContent = '0 / 240';
    replyWatchActive      = false;
    panel.classList.add('open');

    chrome.storage.sync.get(['tone', 'autoSendReply'], data => {
      if (data.tone) tone.value = data.tone;
      sendClose.style.display = data.autoSendReply ? 'inline-flex' : 'none';
    });

    tone.addEventListener('change', () => {
      chrome.storage.sync.set({ tone: tone.value });
    });

    // If manual open and already replied → show persistent warning, disable auto-actions
    if (!autoGenerate) {
      await sleep(700);
      const username = detectOwnUsername();
      const replied  = (username && alreadyRepliedInThread(username)) || alreadyDoneSession(url);
      if (replied) {
        showStatus(panel, '⚠️ You already replied to this tweet.', 'warn');
        // Disable insert & send-close so nothing fires accidentally
        insert.disabled   = true;
        sendClose.disabled = true;
        // Re-enable if user edits output manually (they might want to reply again intentionally)
        output.addEventListener('input', () => {
          insert.disabled    = false;
          sendClose.disabled = false;
        }, { once: true });
      }
    }

    output.addEventListener('input', () => {
      charCount.textContent = `${output.value.length} / 240`;
    });

    // ── Auto-generate ──────────────────────────────────────────────────────
    if (autoGenerate && tweetText.length > 10) {
      gen.disabled = true;
      showStatus(panel, '⚡ Generating smart reply…', 'loading');

      let likedAlready = false;
      chrome.storage.sync.get(['autoLike'], async data => {
        if (data.autoLike) likedAlready = await autoLikeTweet();
      });

      chrome.runtime.sendMessage(
        { type: 'AUTO_GENERATE', payload: { tweetText } },
        async res => {
          gen.disabled = false;
          if (res?.ok && res.data) {
            output.value = res.data;
            charCount.textContent = `${res.data.length} / 240`;
            showStatus(panel, '✅ Reply ready!', 'ok');
            sendClose.style.display = res.autoSendReply ? 'inline-flex' : 'none';
            if (res.autoInsert) {
              await handlePostGenerate(panel, res.data, {
                autoInsert:    res.autoInsert,
                autoSendReply: res.autoSendReply,
                autoCloseTab:  res.autoCloseTab,
                autoLike:      res.autoLike,
                skipLike:      likedAlready
              });
            }
          } else if (res?.skip) {
            showStatus(panel, '⚙️ API Key not set in settings', 'warn');
          } else {
            showStatus(panel, '❌ Error: ' + (res?.error || 'Unknown'), 'err');
          }
        }
      );
    }

    // ── Manual generate ────────────────────────────────────────────────────
    gen.onclick = () => {
      output.value = '';
      showStatus(panel, '⚡ Generating…', 'loading');
      chrome.runtime.sendMessage(
        {
          type: 'GENERATE_REPLY',
          payload: {
            tweetText:        input.value || '',
            tone:             tone.value,
            useSearch:        useSearch.checked,
            translationStyle: panel.dataset.style || 'friendly'
          }
        },
        res => {
          if (!res?.ok) {
            showStatus(panel, '❌ Error: ' + (res?.error || 'Unknown'), 'err');
          } else {
            output.value = res.data || '';
            charCount.textContent = `${(res.data || '').length} / 240`;
            showStatus(panel, '✅ Reply ready!', 'ok');
            // Re-enable insert/send after new generation regardless
            insert.disabled    = false;
            sendClose.disabled = false;
          }
        }
      );
    };

    // ── Insert button ──────────────────────────────────────────────────────
    insert.onclick = async () => {
      if (!output.value) return;
      showStatus(panel, '⬆️ Inserting…', 'loading');
      const inserted = await fillReplyBox(output.value);
      if (!inserted) {
        try {
          await navigator.clipboard.writeText(output.value);
          showStatus(panel, '📋 Copied — paste with Ctrl+V', 'warn');
        } catch {
          showStatus(panel, '❌ Could not insert. Copy manually.', 'err');
        }
        return;
      }
      chrome.storage.sync.get(['autoCloseTab', 'autoSendReply', 'autoLike'], async data => {
        if (data.autoLike) await autoLikeTweet();
        if (data.autoSendReply) {
          await sleep(500);
          const sent = clickTwitterSendBtn();
          if (sent) {
            markDone(url);
            showStatus(panel, '🚀 Sent! Closing tab…', 'ok');
            sleep(1800).then(() => chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId: ownTabId }));
          } else {
            showStatus(panel, '⚠️ Inserted — Send manually.', 'warn');
            if (data.autoCloseTab) watchForReplySent(ownTabId, url);
          }
        } else if (data.autoCloseTab) {
          showStatus(panel, data.autoLike ? '❤️ Liked! Click Send & tab closes.' : '✅ Ready — click Send & tab closes!', 'ok');
          watchForReplySent(ownTabId, url);
        } else {
          showStatus(panel, data.autoLike ? '❤️ Liked & inserted!' : '✅ Inserted!', 'ok');
        }
      });
    };

    // ── Send & Close button ────────────────────────────────────────────────
    sendClose.onclick = async () => {
      if (!output.value) return;
      showStatus(panel, '⬆️ Inserting…', 'loading');
      if (!await fillReplyBox(output.value)) {
        showStatus(panel, '❌ Could not insert.', 'err');
        return;
      }
      chrome.storage.sync.get(['autoLike'], async data => {
        if (data.autoLike) await autoLikeTweet();
        await sleep(500);
        const sent = clickTwitterSendBtn();
        if (sent) {
          markDone(url);
          showStatus(panel, '🚀 Sent! Closing tab…', 'ok');
          sleep(1800).then(() => chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId: ownTabId }));
        } else {
          showStatus(panel, '⚠️ Inserted — Send manually.', 'warn');
          watchForReplySent(ownTabId, url);
        }
      });
    };

    // ── Copy button ────────────────────────────────────────────────────────
    copyBtn.onclick = async () => {
      if (!output.value) return;
      try {
        await navigator.clipboard.writeText(output.value);
        copyBtn.textContent = '✅ Copied!';
        setTimeout(() => (copyBtn.innerHTML = '📋 Copy'), 1200);
      } catch {
        showStatus(panel, '❌ Clipboard permission denied', 'err');
      }
    };
  }

  // ── Auto-open on tweet detail ──────────────────────────────────────────────
  function isTweetDetailPage() {
    return /(\/status\/|\/statuses\/)\d+/.test(location.pathname);
  }

  function tryAutoOpen() {
    const url = location.href;
    if (currentProcessingUrl === url) return;
    if (!isTweetDetailPage()) return;
    if (autoGenInProgress) return;

    const waitForTweet = (attempts = 0) => {
      const text = getActiveTweetText();
      if (text && text.length > 10) {
        currentProcessingUrl = url;
        autoGenInProgress    = true;
        replyWatchActive     = false;
        sleep(800).then(() => {
          onOpen(text, true);
          autoGenInProgress = false;
        });
      } else if (attempts < 20) {
        setTimeout(() => waitForTweet(attempts + 1), 300);
      }
    };
    waitForTweet();
  }

  // ── SPA URL watcher ───────────────────────────────────────────────────────
  let lastHref = location.href;
  new MutationObserver(() => {
    if (location.href !== lastHref) {
      lastHref             = location.href;
      currentProcessingUrl = '';
      autoGenInProgress    = false;
      replyWatchActive     = false;
      setTimeout(tryAutoOpen, 500);
    }
  }).observe(document.body, { childList: true, subtree: true });

  function init() {
    ensureStyles();
    ensureButton();
    setTimeout(tryAutoOpen, 1500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
