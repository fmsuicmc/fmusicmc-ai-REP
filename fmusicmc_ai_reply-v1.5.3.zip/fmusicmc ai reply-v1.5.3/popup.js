// popup.js — v1.1

// ─── i18n ────────────────────────────────────────────────────────────────────
const dict = {
  fa: {
    subtitle:        'Smart Twitter Replies',
    sec_style:       'سبک ریپلای',
    style_friendly:  '😊 دوستانه',
    style_formal:    '🎩 رسمی',
    sec_tone:        'تون پیش‌فرض',
    tone_label:      'تون',
    sec_settings:    'تنظیمات',
    search_label:    'جستجو',
    search_sub:      'کانتکست ویکی‌پدیا',
    autoInsert_label:'قرار دادن خودکار',
    autoInsert_sub:  'بعد از تولید، توی ریپلای باکس میذاره',
    autoClose_label: 'بستن تب بعد از ریپلای',
    autoClose_sub:   'بعد از کلیک ارسال، تب بسته می‌شه',
    autoSend_label:  'ارسال و بستن خودکار',
    autoSend_sub:    'بات خودش ریپلای رو می‌فرسته و تب رو می‌بنده',
    autoLike_label:  '❤️ لایک خودکار',
    autoLike_sub:    'هنگام باز شدن پنل، توییت رو لایک می‌کنه',
    open_btn:        '⚡ باز کردن پنل روی X',
    settings_link:   '⚙️ تنظیمات کامل (API Key)',
    err_not_twitter: '❌ برو روی صفحه X/Twitter'
  },
  en: {
    subtitle:        'Smart Twitter Replies',
    sec_style:       'Reply Style',
    style_friendly:  '😊 Friendly',
    style_formal:    '🎩 Formal',
    sec_tone:        'Default Tone',
    tone_label:      'Tone',
    sec_settings:    'Settings',
    search_label:    'Web Search',
    search_sub:      'Wikipedia context before reply',
    autoInsert_label:'Auto-insert reply',
    autoInsert_sub:  'Places generated text in the reply box',
    autoClose_label: 'Auto-close tab after send',
    autoClose_sub:   'Tab closes after you click Send',
    autoSend_label:  'Full auto-send & close',
    autoSend_sub:    'Bot clicks Send itself, then closes tab',
    autoLike_label:  '❤️ Auto-like tweet',
    autoLike_sub:    'Likes the tweet when the panel opens',
    open_btn:        '⚡ Open panel on X',
    settings_link:   '⚙️ Full Settings (API Key)',
    err_not_twitter: '❌ Navigate to X/Twitter first'
  }
};

let currentLang = 'fa';

const ids = [
  ['t_subtitle',        'subtitle',        'textContent'],
  ['t_sec_style',       'sec_style',       'textContent'],
  ['t_style_friendly',  'style_friendly',  'textContent'],
  ['t_style_formal',    'style_formal',    'textContent'],
  ['t_sec_tone',        'sec_tone',        'textContent'],
  ['t_tone_label',      'tone_label',      'textContent'],
  ['t_sec_settings',    'sec_settings',    'textContent'],
  ['t_search_label',    'search_label',    'textContent'],
  ['t_search_sub',      'search_sub',      'textContent'],
  ['t_autoInsert_label','autoInsert_label','textContent'],
  ['t_autoInsert_sub',  'autoInsert_sub',  'textContent'],
  ['t_autoClose_label', 'autoClose_label', 'textContent'],
  ['t_autoClose_sub',   'autoClose_sub',   'textContent'],
  ['t_autoSend_label',  'autoSend_label',  'textContent'],
  ['t_autoSend_sub',    'autoSend_sub',    'textContent'],
  ['t_autoLike_label',  'autoLike_label',  'textContent'],
  ['t_autoLike_sub',    'autoLike_sub',    'textContent'],
  ['t_settings_link',   'settings_link',   'textContent'],
];

function applyLang(lang) {
  currentLang = lang;
  const t = dict[lang] || dict.fa;
  for (const [id, key, prop] of ids) {
    const el = document.getElementById(id);
    if (el && t[key] !== undefined) el[prop] = t[key];
  }
  document.getElementById('openPanel').textContent = t.open_btn;
  document.documentElement.dir  = lang === 'fa' ? 'rtl' : 'ltr';
  document.documentElement.lang = lang;
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === lang));
}

document.querySelectorAll('.lang-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    applyLang(btn.dataset.lang);
    chrome.storage.sync.set({ popupLang: btn.dataset.lang });
  });
});

// ─── Element refs ─────────────────────────────────────────────────────────────
const toneSelect        = document.getElementById('tone');
const useSearchToggle   = document.getElementById('useSearch');
const autoInsertToggle  = document.getElementById('autoInsert');
const autoCloseToggle   = document.getElementById('autoCloseTab');
const autoSendToggle    = document.getElementById('autoSendReply');
const autoLikeToggle    = document.getElementById('autoLike');
const openPanelBtn      = document.getElementById('openPanel');
const translationStyle  = document.getElementById('translationStyle');
const statusEl          = document.getElementById('status');

// ─── Load settings ────────────────────────────────────────────────────────────
chrome.storage.sync.get(['tone','useSearch','autoInsert','autoCloseTab','autoSendReply','autoLike','translationStyle','popupLang'], (data) => {
  if (data.tone)               toneSelect.value         = data.tone;
  if (data.useSearch   !== undefined) useSearchToggle.checked  = data.useSearch;
  if (data.autoInsert  !== undefined) autoInsertToggle.checked = data.autoInsert;
  if (data.autoCloseTab !== undefined) autoCloseToggle.checked  = !!data.autoCloseTab;
  if (data.autoSendReply !== undefined) autoSendToggle.checked  = !!data.autoSendReply;
  if (data.autoLike    !== undefined) autoLikeToggle.checked   = !!data.autoLike;

  const style = data.translationStyle || 'friendly';
  translationStyle.value = style;
  updateStyleTabs(style);

  applyLang(data.popupLang || 'fa');
});

// ─── Style tabs ───────────────────────────────────────────────────────────────
document.querySelectorAll('.style-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    const style = btn.dataset.style;
    translationStyle.value = style;
    updateStyleTabs(style);
    chrome.storage.sync.set({ translationStyle: style });
  });
});

function updateStyleTabs(style) {
  document.querySelectorAll('.style-tab').forEach(b => b.classList.toggle('active', b.dataset.style === style));
}

// ─── Live save on toggle ──────────────────────────────────────────────────────
toneSelect.addEventListener('change',       () => chrome.storage.sync.set({ tone: toneSelect.value }));
useSearchToggle.addEventListener('change',  () => chrome.storage.sync.set({ useSearch: useSearchToggle.checked }));
autoInsertToggle.addEventListener('change', () => chrome.storage.sync.set({ autoInsert: autoInsertToggle.checked }));
autoCloseToggle.addEventListener('change',  () => chrome.storage.sync.set({ autoCloseTab: autoCloseToggle.checked }));
autoSendToggle.addEventListener('change',   () => chrome.storage.sync.set({ autoSendReply: autoSendToggle.checked }));
autoLikeToggle.addEventListener('change',   () => chrome.storage.sync.set({ autoLike: autoLikeToggle.checked }));

// ─── Open panel ───────────────────────────────────────────────────────────────
openPanelBtn.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab?.url?.match(/x\.com|twitter\.com/)) {
      showStatus(dict[currentLang].err_not_twitter, 'err');
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { document.getElementById('fmusicmc-ai-btn')?.click(); }
    });
    window.close();
  });
});

function showStatus(msg, type) {
  statusEl.textContent = msg;
  statusEl.className   = 'status ' + type;
  setTimeout(() => { statusEl.className = 'status'; }, 3000);
}
