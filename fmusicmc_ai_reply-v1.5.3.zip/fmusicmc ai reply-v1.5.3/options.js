// options.js — v1.1

// ─── i18n dictionary ────────────────────────────────────────────────────────
const dict = {
  fa: {
    title: 'تنظیمات fmusicmc ai',
    sec_api: 'تنظیمات API',
    sec_reply: 'تنظیمات پاسخ',
    sec_behavior: 'رفتار بات',
    sec_own: 'پروژه‌های خودی (تگ + مانور بیشتر)',
    provider: 'ارائه‌دهنده',
    provider_hint: 'سرویسی که هوش مصنوعی از طریق اون کار می‌کنه — OpenRouter, OpenAI یا Custom.',
    endpoint: 'نشانی API',
    endpoint_hint: 'آدرس endpoint مربوط به ارائه‌دهنده. مثال OpenRouter: https://openrouter.ai/api/v1/chat/completions',
    model: 'مدل',
    model_hint: 'نام مدل هوش مصنوعی. مثال: openai/gpt-4o-mini یا anthropic/claude-haiku-4-5',
    apiKey: 'کلید API',
    apiKey_hint: 'کلید خصوصی دسترسی به API. این اطلاعات فقط روی مرورگر شما ذخیره می‌شه.',
    serp: 'کلید SerpAPI (اختیاری)',
    serp_hint: 'برای جستجوی وب به‌جای ویکی‌پدیا. اگر ندارید خالی بذارید.',
    useSearch: 'جستجو فعال باشد؟',
    useSearch_hint: 'اگر فعال باشه، بات قبل از پاسخ اطلاعات پس‌زمینه جمع می‌کنه.',
    tone: 'تون پیش‌فرض',
    tone_hint: 'سبک کلی پاسخ‌ها. می‌تونید هر بار از پنل هم تغییر بدید.',
    maxChars: 'حداکثر کاراکتر پاسخ',
    maxChars_hint: 'پاسخ روی آخرین جمله‌ی کامل قبل از این حد قطع می‌شود.',
    autoCloseTab_label: 'بستن خودکار تب بعد از ریپلای',
    autoCloseTab_sub: 'بعد از کلیک روی دکمه ارسال توییتر، این تب بسته می‌شه.',
    autoSendReply_label: 'ارسال و بستن خودکار کامل',
    autoSendReply_sub: 'بات پاسخ رو می‌ذاره، دکمه ارسال توییتر رو خودش کلیک می‌کنه، بعد تب رو می‌بنده.',
    autoLike_label: '❤️ لایک خودکار توییت',
    autoLike_sub: 'وقتی پنل باز می‌شه توییت رو لایک می‌کنه. اگر قبلاً لایک شده باشه دوباره کاری نمی‌کنه.',
    ownProjects: 'پروژه‌های شخصی (cashtag یا hashtag)',
    ownProjects_hint: 'با کاما جدا کنید. مثال: <code>$XYZ, #MyProject</code><br/>وقتی توییت حاوی این تگ‌ها باشد، بات تگ می‌زند و بیشتر روی پروژه مانور می‌دهد.<br/>برای سایر پروژه‌ها: نام مستقیم نمی‌آید و بی‌طرف می‌ماند.',
    footer_hint: 'پاسخ به‌صورت خودکار ارسال نمی‌شود مگر گزینه «ارسال خودکار» فعال باشد.',
    save: 'ذخیره',
    reset: 'بازنشانی',
    saved: 'ذخیره شد.',
    resetDone: 'بازنشانی شد.'
  },
  en: {
    title: 'fmusicmc ai Settings',
    sec_api: 'API Settings',
    sec_reply: 'Reply Settings',
    sec_behavior: 'Bot Behavior',
    sec_own: 'Own Projects (tag + promote)',
    provider: 'Provider',
    provider_hint: 'The service powering the AI — OpenRouter, OpenAI, or a Custom endpoint.',
    endpoint: 'API Endpoint',
    endpoint_hint: 'Full endpoint URL for your provider. Example: https://openrouter.ai/api/v1/chat/completions',
    model: 'Model',
    model_hint: 'AI model name. Example: openai/gpt-4o-mini or anthropic/claude-haiku-4-5',
    apiKey: 'API Key',
    apiKey_hint: 'Your private API key. Stored only in your browser — never sent anywhere else.',
    serp: 'SerpAPI Key (optional)',
    serp_hint: 'For live web search instead of Wikipedia. Leave blank if you don\'t have one.',
    useSearch: 'Enable search?',
    useSearch_hint: 'If enabled, the bot gathers background context before replying.',
    tone: 'Default tone',
    tone_hint: 'Overall reply style. You can change this per-reply from the panel too.',
    maxChars: 'Max reply characters',
    maxChars_hint: 'Reply will be cut at the last complete sentence before this limit.',
    autoCloseTab_label: 'Auto-close tab after reply',
    autoCloseTab_sub: 'Once you click Twitter\'s Send button, this tab closes automatically.',
    autoSendReply_label: 'Full auto-send & close',
    autoSendReply_sub: 'Bot inserts reply, clicks Twitter\'s Send button itself, then closes the tab.',
    autoLike_label: '❤️ Auto-like tweet',
    autoLike_sub: 'Likes the tweet when the panel opens. Skips if already liked.',
    ownProjects: 'Your own projects (cashtag or hashtag)',
    ownProjects_hint: 'Comma-separated. Example: <code>$XYZ, #MyProject</code><br/>When a tweet contains these tags, the bot will tag and promote the project.<br/>For all other projects: stays neutral, no direct name.',
    footer_hint: 'Replies are not auto-sent unless the "Full auto-send" option is enabled.',
    save: 'Save',
    reset: 'Reset',
    saved: 'Saved.',
    resetDone: 'Reset done.'
  }
};

// ─── Element ID → dict key map ──────────────────────────────────────────────
const idMap = [
  ['t_title',               'title',               'textContent'],
  ['t_sec_api',             'sec_api',             'textContent'],
  ['t_sec_reply',           'sec_reply',           'textContent'],
  ['t_sec_behavior',        'sec_behavior',        'textContent'],
  ['t_sec_own',             'sec_own',             'textContent'],
  ['t_provider',            'provider',            'textContent'],
  ['t_provider_hint',       'provider_hint',       'innerHTML'],
  ['t_endpoint',            'endpoint',            'textContent'],
  ['t_endpoint_hint',       'endpoint_hint',       'innerHTML'],
  ['t_model',               'model',               'textContent'],
  ['t_model_hint',          'model_hint',          'innerHTML'],
  ['t_apiKey',              'apiKey',              'textContent'],
  ['t_apiKey_hint',         'apiKey_hint',         'innerHTML'],
  ['t_serp',                'serp',                'textContent'],
  ['t_serp_hint',           'serp_hint',           'innerHTML'],
  ['t_useSearch',           'useSearch',           'textContent'],
  ['t_useSearch_hint',      'useSearch_hint',      'innerHTML'],
  ['t_tone',                'tone',                'textContent'],
  ['t_tone_hint',           'tone_hint',           'innerHTML'],
  ['t_maxChars',            'maxChars',            'textContent'],
  ['t_maxChars_hint',       'maxChars_hint',       'innerHTML'],
  ['t_autoCloseTab_label',  'autoCloseTab_label',  'textContent'],
  ['t_autoCloseTab_sub',    'autoCloseTab_sub',    'textContent'],
  ['t_autoSendReply_label', 'autoSendReply_label', 'textContent'],
  ['t_autoSendReply_sub',   'autoSendReply_sub',   'textContent'],
  ['t_autoLike_label',      'autoLike_label',      'textContent'],
  ['t_autoLike_sub',        'autoLike_sub',        'textContent'],
  ['t_ownProjects',         'ownProjects',         'textContent'],
  ['t_ownProjects_hint',    'ownProjects_hint',    'innerHTML'],
  ['t_footer_hint',         'footer_hint',         'textContent'],
];

let currentLang = 'fa';

function applyLang(lang) {
  currentLang = lang;
  const t = dict[lang] || dict.fa;
  for (const [id, key, prop] of idMap) {
    const el = document.getElementById(id);
    if (el && t[key] !== undefined) el[prop] = t[key];
  }
  document.getElementById('save').textContent  = t.save;
  document.getElementById('reset').textContent = t.reset;
  document.documentElement.dir  = lang === 'fa' ? 'rtl' : 'ltr';
  document.documentElement.lang = lang;
}

// ─── Load & Save ─────────────────────────────────────────────────────────────
async function load() {
  const defaults = {
    enabled: true,
    tone: 'friendly',
    useSearch: true,
    maxChars: 240,
    provider: 'openrouter',
    endpoint: 'https://openrouter.ai/api/v1/chat/completions',
    model: 'anthropic/claude-haiku-4-5',
    apiKey: '',
    serpApiKey: '',
    ownProjects: '',          // empty by default — user fills their own
    autoCloseTab: true,
    autoSendReply: false,
    autoLike: false
  };
  const data = await new Promise(resolve => chrome.storage.sync.get(defaults, resolve));

  document.getElementById('provider').value      = data.provider;
  document.getElementById('endpoint').value      = data.endpoint;
  document.getElementById('model').value         = data.model;
  document.getElementById('apiKey').value        = data.apiKey;
  document.getElementById('serpApiKey').value    = data.serpApiKey;
  document.getElementById('tone').value          = data.tone;
  document.getElementById('maxChars').value      = String(data.maxChars || 240);
  document.getElementById('useSearch').value     = String(!!data.useSearch);
  document.getElementById('ownProjects').value   = data.ownProjects || '';
  document.getElementById('autoCloseTab').checked  = !!data.autoCloseTab;
  document.getElementById('autoSendReply').checked = !!data.autoSendReply;
  document.getElementById('autoLike').checked      = !!data.autoLike;
}

async function save() {
  const payload = {
    provider:       document.getElementById('provider').value,
    endpoint:       document.getElementById('endpoint').value.trim(),
    model:          document.getElementById('model').value.trim(),
    apiKey:         document.getElementById('apiKey').value.trim(),
    serpApiKey:     document.getElementById('serpApiKey').value.trim(),
    tone:           document.getElementById('tone').value,
    maxChars:       parseInt(document.getElementById('maxChars').value || '240', 10),
    useSearch:      document.getElementById('useSearch').value === 'true',
    ownProjects:    document.getElementById('ownProjects').value.trim(),
    autoCloseTab:   document.getElementById('autoCloseTab').checked,
    autoSendReply:  document.getElementById('autoSendReply').checked,
    autoLike:       document.getElementById('autoLike').checked
  };
  await new Promise(resolve => chrome.storage.sync.set(payload, resolve));
  showToast(dict[currentLang].saved);
}

async function resetAll() {
  await new Promise(resolve => chrome.storage.sync.clear(resolve));
  await load();
  showToast(dict[currentLang].resetDone);
}

function showToast(msg) {
  let t = document.getElementById('_toast');
  if (!t) {
    t = document.createElement('div');
    t.id = '_toast';
    t.style.cssText = 'position:fixed;bottom:20px;right:20px;background:#111;color:#fff;padding:10px 16px;border-radius:10px;font-size:14px;z-index:9999;transition:opacity .3s';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.opacity = '1';
  clearTimeout(t._to);
  t._to = setTimeout(() => { t.style.opacity = '0'; }, 2000);
}

// ─── Init ─────────────────────────────────────────────────────────────────────
document.getElementById('save').addEventListener('click', save);
document.getElementById('reset').addEventListener('click', resetAll);
document.getElementById('langSwitcher').addEventListener('change', (e) => applyLang(e.target.value));

applyLang('fa');
load();
