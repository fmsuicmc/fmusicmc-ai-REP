// content.js — v1.7.0 (fmusicmc)
(function () {
  const STYLE_ID = 'fmusicmc-ai-style';
  const BTN_ID   = 'fmusicmc-ai-btn';
  const PANEL_ID = 'fmusicmc-ai-panel';

  let ownTabId = null;
  let cachedOwnUsername = null;

  chrome.runtime.sendMessage({ type: 'GET_TAB_ID' }, res => {
    if (res?.tabId) ownTabId = res.tabId;
  });

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const link = document.createElement('link');
    link.id   = STYLE_ID;
    link.rel  = 'stylesheet';
    link.href = chrome.runtime.getURL('styles/overlay.css');
    document.documentElement.appendChild(link);
  }

  function createPanel() {
    let panel = document.getElementById(PANEL_ID);
    if (panel) return panel;

    panel = document.createElement('div');
    panel.id        = PANEL_ID;
    panel.className = 'fm-overlay';
    panel.innerHTML = `
      <div class="fm-header">
        <img src="${chrome.runtime.getURL('icons/icon128.png')}" class="fm-logo" alt="fmusicmc">
        <div class="fm-title">fmusicmc ai Pro</div>
        <button class="fm-close" aria-label="Close">×</button>
      </div>
      <div class="fm-body">
        <textarea id="fm-input" class="fm-text" placeholder="متن توییت..."></textarea>
        <div class="fm-controls">
          <select id="fm-tone">
            <option value="friendly">دوستانه</option>
            <option value="professional">حرفه‌ای</option>
            <option value="witty">طنز</option>
            <option value="analytical" selected>تحلیلی</option>
            <option value="neutral">خنثی</option>
          </select>
          <button id="fm-generate" class="fm-primary">⚡ تولید پاسخ</button>
        </div>
        <div class="fm-output-wrap">
          <textarea id="fm-output" class="fm-text fm-output-text" placeholder="پاسخ هوش مصنوعی..." readonly></textarea>
        </div>
        <div class="fm-actions">
          <button id="fm-insert" class="fm-secondary">⬆️ درج در ریپلای</button>
          <button id="fm-copy" class="fm-ghost">📋 کپی</button>
        </div>
        <div class="fm-status" id="fm-status"></div>
      </div>
    `;
    document.body.appendChild(panel);
    panel.querySelector('.fm-close')?.addEventListener('click', () => panel.classList.remove('open'));
    return panel;
  }

  function ensureButton() {
    if (document.getElementById(BTN_ID)) return;
    const btn = document.createElement('button');
    btn.id        = BTN_ID;
    btn.className = 'fm-fab';
    btn.title     = 'fmusicmc ai';
    btn.innerHTML = `<img src="${chrome.runtime.getURL('icons/icon128.png')}" style="width:20px;height:20px;border-radius:50%;vertical-align:middle;margin-left:6px;"> fmusicmc ai`;
    btn.addEventListener('click', () => onOpen());
    document.body.appendChild(btn);
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function getActiveTweetText() {
    const detail = document.querySelector('article [data-testid="tweetText"]');
    if (detail?.innerText?.trim()) return detail.innerText.trim();
    return '';
  }

  // تشخیص نام کاربری خودِ اکانت لاگین‌شده در توییتر
  function detectOwnUsername() {
    if (cachedOwnUsername) return cachedOwnUsername;

    const switcher = document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"]');
    if (switcher) {
      const label = switcher.getAttribute('aria-label') || '';
      const m = label.match(/@([\w\d_]+)/);
      if (m) { cachedOwnUsername = m[1].toLowerCase(); return cachedOwnUsername; }
    }

    const profileLink = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
    if (profileLink) {
      const href = profileLink.getAttribute('href') || '';
      const m = href.match(/^\/([^/?#]+)/);
      if (m && m[1] !== 'home' && m[1] !== 'explore') {
        cachedOwnUsername = m[1].toLowerCase();
        return cachedOwnUsername;
      }
    }
    return null;
  }

  // بررسی اینکه آیا قبلاً در این ترد توسط خودمان پاسخ داده شده است یا خیر
  function alreadyRepliedInThread(ownUsername) {
    if (!ownUsername) return false;
    const articles = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));
    // از مقاله دوم به بعد (کامنت‌ها و پاسخ‌ها) را چک می‌کنیم
    for (let i = 1; i < articles.length; i++) {
      const article = articles[i];
      const userLink = article.querySelector('a[role="link"][href^="/"]');
      if (userLink) {
        const href = userLink.getAttribute('href') || '';
        const m = href.match(/^\/([^/?#]+)/);
        if (m && m[1].toLowerCase() === ownUsername) return true;
      }
    }
    return false;
  }

  async function fillReplyBox(text) {
    const composer = document.querySelector('div[contenteditable="true"][role="textbox"]');
    if (!composer) return false;
    composer.focus();
    document.execCommand('insertText', false, text);
    return true;
  }

  async function autoLikeTweet() {
    if (document.querySelector('article [data-testid="unlike"]')) return false;
    const likeBtn = document.querySelector('article [data-testid="like"]');
    if (!likeBtn) return false;
    likeBtn.click();
    await sleep(350);
    return true;
  }

  async function onOpen(prefillText = '', isAuto = false) {
    ensureStyles();
    const panel = createPanel();
    const input = panel.querySelector('#fm-input');
    const output = panel.querySelector('#fm-output');
    const tone = panel.querySelector('#fm-tone');
    const gen = panel.querySelector('#fm-generate');
    const insert = panel.querySelector('#fm-insert');

    const tweetText = prefillText || getActiveTweetText() || '';
    input.value = tweetText;
    panel.classList.add('open');

    chrome.storage.sync.get(['botMode', 'autoSendReply', 'keepTabOpen', 'autoLike'], async data => {
      if (data.botMode === 'manual' && !isAuto) return;

      // چک کردن اینکه آیا قبلاً به این توییت ریپلای داده‌ایم یا خیر
      await sleep(1000);
      const username = detectOwnUsername();
      if (isAuto && username && alreadyRepliedInThread(username)) {
        // اگر قبلاً پاسخ داده بودیم، از ارسال خودکار صرف‌نظر کرده و تب را می‌بندیم
        setTimeout(() => chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId: ownTabId }), 1500);
        return;
      }

      if (data.autoLike && isAuto) {
        await sleep(500);
        await autoLikeTweet();
      }

      if (isAuto && tweetText.length > 3) {
        gen.click();
      }
    });

    gen.onclick = () => {
      chrome.runtime.sendMessage(
        { type: 'GENERATE_REPLY', payload: { tweetText: input.value, tone: tone.value } },
        res => {
          if (res?.ok) {
            output.value = res.data;
            chrome.storage.sync.get(['autoSendReply', 'keepTabOpen', 'autoInsert'], async settings => {
              if (settings.autoInsert !== false) {
                await fillReplyBox(res.data);
                
                if (settings.autoSendReply || settings.keepTabOpen) {
                  await sleep(1000);
                  const sendBtn = document.querySelector('[data-testid="tweetButtonInline"]') || document.querySelector('[data-testid="tweetButton"]');
                  if (sendBtn) {
                    sendBtn.click();
                    if (!settings.keepTabOpen && settings.autoSendReply) {
                      setTimeout(() => chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId: ownTabId }), 2500);
                    }
                  }
                }
              }
            });
          }
        }
      );
    };

    insert.onclick = async () => {
      if (output.value) await fillReplyBox(output.value);
    };
  }

  function triggerAutoModeIfReady() {
    chrome.storage.sync.get(['botMode'], data => {
      if (data.botMode !== 'manual' && /(\/status\/|\/statuses\/)\d+/.test(location.pathname)) {
        let attempts = 0;
        const timer = setInterval(() => {
          attempts++;
          const text = getActiveTweetText();
          if (text) {
            clearInterval(timer);
            onOpen(text, true);
          } else if (attempts > 25) {
            clearInterval(timer);
          }
        }, 600);
      }
    });
  }

  let lastPath = location.pathname;
  setInterval(() => {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      triggerAutoModeIfReady();
    }
  }, 1000);

  function init() {
    ensureStyles();
    ensureButton();
    triggerAutoModeIfReady();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();