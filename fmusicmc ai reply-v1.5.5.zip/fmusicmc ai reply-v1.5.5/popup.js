// popup.js — v1.8
const autoSendToggle        = document.getElementById('autoSendReply');
const keepTabOpenToggle     = document.getElementById('keepTabOpen');
const autoLikeToggle        = document.getElementById('autoLike');
const autoSettingsContainer = document.getElementById('autoSettingsContainer');
const openPanelBtn          = document.getElementById('openPanel');
const startBatchBtn         = document.getElementById('startBatchBtn');
const clearQueueBtn         = document.getElementById('clearQueueBtn');
const tweetListInput        = document.getElementById('tweetListInput');
const timerIntervalSelect   = document.getElementById('timerInterval');
const queueCountEl          = document.getElementById('queueCount');
const timerDisplayEl        = document.getElementById('timerDisplay');
const pinSidebarBtn         = document.getElementById('pinSidebarBtn');
const statusEl              = document.getElementById('status');

let countdownInterval = null;
let targetTimestamp = null;

const i18n = {
  fa: {
    title: 'fmusicmc ai Pro', subtitle: 'کنترل پنل هوشمند توییت‌ها',
    pin_btn: '📌 پین کردن به عنوان سایدبار مرورگر',
    sec_mode: 'انتخاب حالت اجرا', mode_auto: '⚡ حالت خودکار', mode_manual: '✋ حالت تمام‌دستی',
    sec_auto_settings: 'تنظیمات پیشرفته خودکار',
    lbl_autosend: 'ارسال و بستن خودکار تب', sub_autosend: 'ارسال ریپلای + بستن تب',
    lbl_keeptab: 'ارسال ولی بسته نشدن تب', sub_keeptab: 'ریپلای ارسال شود اما تب باز بماند',
    lbl_autolike: '❤️ لایک خودکار توییت', sub_autolike: 'لایک کردن هنگام ورود',
    sec_batch: 'پردازش دسته‌ای توییت‌ها و ثانیه‌شمار',
    lbl_timer: 'فاصله زمانی بین هر توییت:',
    btn_batch: '🚀 شروع صف هوشمند توییت‌ها',
    btn_open: '⚡ باز کردن پنل روی تب فعلی X',
    link_settings: '⚙️ تنظیمات کامل و API Key',
    err_empty: '❌ لطفاً لینک توییت‌ها را وارد کنید',
    err_no_url: '❌ هیچ لینک معتبر توییتی یافت نشد',
    msg_auto: '⚡ حالت خودکار فعال شد',
    msg_manual: '✋ حالت تمام‌دستی فعال شد (بدون اتومیشن)',
    msg_started: '✅ صف توییت‌ها با موفقیت استارت شد',
    msg_cleared: '🗑️ صف توییت‌ها پاک و ریست شد'
  },
  en: {
    title: 'fmusicmc ai Pro', subtitle: 'Smart Tweet Control Panel',
    pin_btn: '📌 Pin as Browser Sidebar',
    sec_mode: 'Execution Mode', mode_auto: '⚡ Auto Mode', mode_manual: '✋ Full Manual Mode',
    sec_auto_settings: 'Advanced Auto Settings',
    lbl_autosend: 'Auto-send & close tab', sub_autosend: 'Send reply + close tab',
    lbl_keeptab: 'Send without closing tab', sub_keeptab: 'Reply sent but tab remains open',
    lbl_autolike: '❤️ Auto-like tweet', sub_autolike: 'Likes tweet upon opening',
    sec_batch: 'Batch Tweet Queue & Countdown',
    lbl_timer: 'Interval between tweets:',
    btn_batch: '🚀 Start Smart Tweet Queue',
    btn_open: '⚡ Open panel on current X tab',
    link_settings: '⚙️ Full Settings & API Key',
    err_empty: '❌ Please enter tweet links',
    err_no_url: '❌ No valid tweet links found',
    msg_auto: '⚡ Auto mode activated',
    msg_manual: '✋ Manual mode activated (No automation)',
    msg_started: '✅ Tweet queue successfully started',
    msg_cleared: '🗑️ Tweet queue cleared and reset'
  }
};

function applyPopupLang(lang) {
  const t = i18n[lang] || i18n.fa;
  document.getElementById('ui_title').textContent = t.title;
  document.getElementById('ui_subtitle').textContent = t.subtitle;
  pinSidebarBtn.textContent = t.pin_btn;
  document.getElementById('ui_sec_mode').textContent = t.sec_mode;
  document.getElementById('ui_mode_auto').textContent = t.mode_auto;
  document.getElementById('ui_mode_manual').textContent = t.mode_manual;
  document.getElementById('ui_sec_auto_settings').textContent = t.sec_auto_settings;
  document.getElementById('ui_lbl_autosend').textContent = t.lbl_autosend;
  document.getElementById('ui_sub_autosend').textContent = t.sub_autosend;
  document.getElementById('ui_lbl_keeptab').textContent = t.lbl_keeptab;
  document.getElementById('ui_sub_keeptab').textContent = t.sub_keeptab;
  document.getElementById('ui_lbl_autolike').textContent = t.lbl_autolike;
  document.getElementById('ui_sub_autolike').textContent = t.sub_autolike;
  document.getElementById('ui_sec_batch').textContent = t.sec_batch;
  document.getElementById('ui_lbl_timer').textContent = t.lbl_timer;
  document.getElementById('startBatchBtn').textContent = t.btn_batch;
  document.getElementById('openPanel').textContent = t.btn_open;
  document.getElementById('ui_link_settings').textContent = t.link_settings;
  document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
  document.documentElement.lang = lang;
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === lang));
}

pinSidebarBtn.addEventListener('click', () => {
  if (chrome.sidePanel && chrome.sidePanel.open) {
    chrome.windows.getCurrent(window => {
      chrome.sidePanel.open({ windowId: window.id }, () => {});
    });
  } else {
    alert('سایدبار در این نسخه مرورگر پشتیبانی نمی‌شود.');
  }
});

function updateQueueState() {
  chrome.storage.local.get(['tweetQueue', 'nextTweetTime'], data => {
    const queue = data.tweetQueue || [];
    queueCountEl.textContent = queue.length;
    targetTimestamp = data.nextTweetTime || 0;
  });
}

function startCountdownTimer() {
  if (countdownInterval) clearInterval(countdownInterval);

  countdownInterval = setInterval(() => {
    updateQueueState();
    if (!targetTimestamp || Date.now() >= targetTimestamp) {
      timerDisplayEl.textContent = '00:00';
      return;
    }

    const diff = Math.floor((targetTimestamp - Date.now()) / 1000);
    const mins = Math.floor(diff / 60).toString().padStart(2, '0');
    const secs = (diff % 60).toString().padStart(2, '0');
    timerDisplayEl.textContent = `${mins}:${secs}`;
  }, 1000);
}

setInterval(updateQueueState, 1000);

document.querySelectorAll('.lang-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const lang = btn.dataset.lang;
    applyPopupLang(lang);
    chrome.storage.sync.set({ popupLang: lang });
  });
});

function updateModeUI(mode) {
  document.querySelectorAll('.mode-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.mode === mode);
  });
  if (mode === 'manual') {
    autoSettingsContainer.classList.add('hidden');
    tweetListInput.parentElement.parentElement.classList.add('hidden');
  } else {
    autoSettingsContainer.classList.remove('hidden');
    tweetListInput.parentElement.parentElement.classList.remove('hidden');
  }
}

chrome.storage.sync.get(['autoSendReply', 'keepTabOpen', 'autoLike', 'botMode', 'popupLang'], (data) => {
  if (data.autoSendReply !== undefined) autoSendToggle.checked = !!data.autoSendReply;
  if (data.keepTabOpen !== undefined) keepTabOpenToggle.checked = !!data.keepTabOpen;
  if (data.autoLike    !== undefined) autoLikeToggle.checked    = !!data.autoLike;
  const mode = data.botMode || 'auto';
  updateModeUI(mode);
  applyPopupLang(data.popupLang || 'fa');
  updateQueueState();
  startCountdownTimer();
});

document.querySelectorAll('.mode-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const mode = btn.dataset.mode;
    updateModeUI(mode);
    chrome.storage.sync.set({ botMode: mode, enabled: mode === 'auto' });
    const lang = document.documentElement.lang || 'fa';
    showStatus(mode === 'auto' ? i18n[lang].msg_auto : i18n[lang].msg_manual, 'ok');
  });
});

autoSendToggle.addEventListener('change', () => {
  chrome.storage.sync.set({ autoSendReply: autoSendToggle.checked });
  if (autoSendToggle.checked && keepTabOpenToggle.checked) {
    keepTabOpenToggle.checked = false;
    chrome.storage.sync.set({ keepTabOpen: false });
  }
});

keepTabOpenToggle.addEventListener('change', () => {
  chrome.storage.sync.set({ keepTabOpen: keepTabOpenToggle.checked });
  if (keepTabOpenToggle.checked && autoSendToggle.checked) {
    autoSendToggle.checked = false;
    chrome.storage.sync.set({ autoSendReply: false });
  }
});

autoLikeToggle.addEventListener('change', () => chrome.storage.sync.set({ autoLike: autoLikeToggle.checked }));

// دکمه پاک کردن کل صف و ریست شمارنده
clearQueueBtn.addEventListener('click', () => {
  const lang = document.documentElement.lang || 'fa';
  chrome.storage.local.set({ tweetQueue: [], nextTweetTime: 0 }, () => {
    updateQueueState();
    showStatus(i18n[lang].msg_cleared, 'ok');
  });
});

startBatchBtn.addEventListener('click', () => {
  const lang = document.documentElement.lang || 'fa';
  const rawText = tweetListInput.value.trim();
  if (!rawText) {
    showStatus(i18n[lang].err_empty, 'err');
    return;
  }
  const urlRegex = /https?:\/\/(?:www\.)?(?:x|twitter)\.com\/[^\s]+/g;
  const foundUrls = rawText.match(urlRegex) || [];
  const urls = [...new Set(foundUrls)];

  if (urls.length === 0) {
    showStatus(i18n[lang].err_no_url, 'err');
    return;
  }

  const intervalMinutes = parseFloat(timerIntervalSelect.value || '0');
  const delayMs = intervalMinutes * 60 * 1000;
  targetTimestamp = Date.now() + delayMs;

  chrome.storage.local.set({ nextTweetTime: targetTimestamp }, () => {
    chrome.runtime.sendMessage({ type: 'START_TWEET_QUEUE', payload: { urls, intervalMinutes } }, res => {
      if (res?.ok) {
        showStatus(i18n[lang].msg_started, 'ok');
        tweetListInput.value = '';
        updateQueueState();
      }
    });
  });
});

openPanelBtn.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab?.url?.match(/x\.com|twitter\.com/)) {
      showStatus('❌ لطفاً در صفحه X/Twitter باشید', 'err');
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { document.getElementById('fmusicmc-ai-btn')?.click(); }
    });
    window.close();
  });
});

function showStatus(msg, type) {
  statusEl.textContent = msg;
  statusEl.className   = 'status ' + type;
  setTimeout(() => { statusEl.className = 'status'; }, 3500);
}