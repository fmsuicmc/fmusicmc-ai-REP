// background.js (MV3, type: module)

import { extractEntities, detectLanguage, clamp } from './lib/utils.js';
import { smartSearch } from './lib/search.js';
import { chatReply } from './lib/llm.js';

async function getSettings() {
  const defaults = {
    enabled: true,
    tone: 'friendly', // friendly | professional | witty | analytical | neutral
    useSearch: true,
    maxChars: 240,
    provider: 'openai', // openai | openrouter | custom
    endpoint: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini',
    apiKey: '',
    serpApiKey: ''
  };
  return new Promise((resolve) => {
    chrome.storage.sync.get(defaults, resolve);
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'GENERATE_REPLY') {
    (async () => {
      try {
        const settings = await getSettings();

        const tweetText = msg.payload?.tweetText?.trim() || '';
        const lang = detectLanguage(tweetText);
        const entities = extractEntities(tweetText);

        let facts = '';
        if (settings.useSearch && msg.payload?.useSearch !== false) {
          const q = (entities?.keywords || []).slice(0, 3).join(' ') || tweetText.slice(0, 120);
          if (q && settings.serpApiKey) {
            try {
              facts = await smartSearch(q, settings.serpApiKey);
            } catch (e) {
              facts = '';
            }
          }
        }

        const req = {
          tweetText,
          lang,
          tone: msg.payload?.tone || settings.tone,
          maxChars: msg.payload?.maxChars || settings.maxChars,
          entities,
          facts
        };

        const api = {
          provider: settings.provider,
          endpoint: settings.endpoint,
          model: settings.model,
          apiKey: settings.apiKey
        };

        const replyText = await chatReply(req, api);
        sendResponse({ ok: true, data: clamp(replyText, settings.maxChars) });
      } catch (err) {
        sendResponse({ ok: false, error: String(err?.message || err) });
      }
    })();
    return true; // keep port open for async
  }
});
