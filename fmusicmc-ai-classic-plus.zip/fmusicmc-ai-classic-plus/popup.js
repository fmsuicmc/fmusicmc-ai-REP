// popup.js
async function loadDefaults() {
  const defaults = { tone: 'friendly', useSearch: true };
  return new Promise((resolve) => chrome.storage.sync.get(defaults, resolve));
}

document.getElementById('openPanel').addEventListener('click', async () => {
  const { tone } = await loadDefaults();
  const useSearch = document.getElementById('useSearch').checked;
  // Run a small script in the active tab to open the panel & set tone
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: ({ tone, useSearch }) => {
      const e = new CustomEvent('fmusicmc-open', { detail: { tone, useSearch } });
      window.dispatchEvent(e);
      // Try to click our button if exists
      const btn = document.getElementById('fmusicmc-ai-btn');
      btn?.click();
    },
    args: [{ tone: document.getElementById('tone').value || tone, useSearch }]
  });
  window.close();
});

// keep tone selection in sync
loadDefaults().then(({ tone, useSearch }) => {
  document.getElementById('tone').value = tone;
  document.getElementById('useSearch').checked = !!useSearch;
});
