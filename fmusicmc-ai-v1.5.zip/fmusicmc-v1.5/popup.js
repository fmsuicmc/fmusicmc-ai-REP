// popup.js — v1.5 — auto/manual mode split + free model presets

// ─── i18n ─────────────────────────────────────────────────────────────────────
const dict = {
  fa: {
    subtitle:         'Smart Twitter Replies',
    mode_auto:        'خودکار',
    mode_manual:      'دستی',
    auto_flow_title:  '⚡ جریان خودکار',
    step_like:        'لایک توییت',
    step_gen:         'تولید ریپلای با AI',
    step_check:       'اگه قبلاً ریپلای داده',
    step_send:        'ارسال ریپلای',
    step_close:       'بستن تب',
    badge_auto:       'خودکار',
    badge_skip:       'رد میکنه',
    sec_model:        'مدل AI',
    model_label:      'مدل پیشنهادی (رایگان)',
    custom_model:     'آیدی مدل',
    open_btn:         'باز کردن پنل روی X',
    sec_style_m:      'سبک ریپلای',
    style_friendly:   '😊 دوستانه',
    style_formal:     '🎩 رسمی',
    sec_tone_m:       'تون',
    sec_options_m:    'گزینه‌ها',
    search_text:      'جستجو (ویکی‌پدیا)',
    search_sub:       'کانتکست پس‌زمینه قبل از ریپلای',
    autoLike_text:    'لایک خودکار',
    autoLike_sub:     'توییت رو لایک می‌کنه (اگه قبلاً نشده)',
    autoInsert_text:  'درج خودکار',
    autoInsert_sub:   'ریپلای رو توی باکس میذاره',
    autoSend_text:    'ارسال خودکار',
    autoSend_sub:     'دکمه Send توییتر رو کلیک می‌کنه',
    autoClose_text:   'بستن تب بعد از ارسال',
    autoClose_sub:    'بعد از کلیک Send، تب بسته می‌شه',
    open_manual_btn:  'باز کردن پنل دستی',
    settings_link:    '⚙️ تنظیمات پیشرفته (API Key)',
    err_not_twitter:  '❌ برو روی صفحه X/Twitter'
  },
  en: {
    subtitle:         'Smart Twitter Replies',
    mode_auto:        'Auto',
    mode_manual:      'Manual',
    auto_flow_title:  '⚡ Automatic Flow',
    step_like:        'Like the tweet',
    step_gen:         'Generate reply with AI',
    step_check:       'If already replied',
    step_send:        'Send reply',
    step_close:       'Close tab',
    badge_auto:       'auto',
    badge_skip:       'skips',
    sec_model:        'AI Model',
    model_label:      'Recommended model (free)',
    custom_model:     'Model ID',
    open_btn:         'Open panel on X',
    sec_style_m:      'Reply Style',
    style_friendly:   '😊 Friendly',
    style_formal:     '🎩 Formal',
    sec_tone_m:       'Tone',
    sec_options_m:    'Options',
    search_text:      'Web Search (Wikipedia)',
    search_sub:       'Background context before reply',
    autoLike_text:    'Auto-like tweet',
    autoLike_sub:     'Likes the tweet if not already liked',
    autoInsert_text:  'Auto-insert reply',
    autoInsert_sub:   'Places generated text in reply box',
    autoSend_text:    'Auto-send reply',
    autoSend_sub:     'Clicks Twitter\'s Send button',
    autoClose_text:   'Close tab after send',
    autoClose_sub:    'Tab closes after Send is clicked',
    open_manual_btn:  'Open manual panel',
    settings_link:    '⚙️ Advanced Settings (API Key)',
    err_not_twitter:  '❌ Navigate to X/Twitter first'
  }
};

// text-only map (id → key)
const textMap = [
  ['t_subtitle',        'subtitle'],
  ['t_mode_auto',       'mode_auto'],
  ['t_mode_manual',     'mode_manual'],
  ['t_auto_flow_title', 'auto_flow_title'],
  ['t_step_like',       'step_like'],
  ['t_step_gen',        'step_gen'],
  ['t_step_check',      'step_check'],
  ['t_step_send',       'step_send'],
  ['t_step_close',      'step_close'],
  ['t_badge_auto',      'badge_auto'],
  ['t_badge_auto2',     'badge_auto'],
  ['t_badge_auto3',     'badge_auto'],
  ['t_badge_auto4',     'badge_auto'],
  ['t_badge_skip',      'badge_skip'],
  ['t_sec_model',       'sec_model'],
  ['t_model_label',     'model_label'],
  ['t_custom_model',    'custom_model'],
  ['t_open_btn',        'open_btn'],
  ['t_sec_style_m',     'sec_style_m'],
  ['t_style_friendly',  'style_friendly'],
  ['t_style_formal',    'style_formal'],
  ['t_sec_tone_m',      'sec_tone_m'],
  ['t_sec_options_m',   'sec_options_m'],
  ['t_search_text',     'search_text'],
  ['t_search_sub',      'search_sub'],
  ['t_autoLike_text',   'autoLike_text'],
  ['t_autoLike_sub',    'autoLike_sub'],
  ['t_autoInsert_text', 'autoInsert_text'],
  ['t_autoInsert_sub',  'autoInsert_sub'],
  ['t_autoSend_text',   'autoSend_text'],
  ['t_autoSend_sub',    'autoSend_sub'],
  ['t_autoClose_text',  'autoClose_text'],
  ['t_autoClose_sub',   'autoClose_sub'],
  ['t_open_manual_btn', 'open_manual_btn'],
  ['t_settings_link',   'settings_link'],
];

let currentLang = 'fa';

function applyLang(lang) {
  currentLang = lang;
  const t = dict[lang] || dict.fa;
  for (const [id, key] of textMap) {
    const el = document.getElementById(id);
    if (el && t[key]) el.textContent = t[key];
  }
  document.documentElement.dir  = lang === 'fa' ? 'rtl' : 'ltr';
  document.documentElement.lang = lang;
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === lang));
}

// ─── Mode switching ────────────────────────────────────────────────────────────
document.querySelectorAll('.mode-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    const mode = tab.dataset.mode;
    document.querySelectorAll('.mode-tab').forEach(t => t.classList.toggle('active', t.dataset.mode === mode));
    document.querySelectorAll('.mode-section').forEach(s => s.classList.toggle('active', s.id === 'section-' + mode));
    chrome.storage.sync.set({ popupMode: mode });
  });
});

// ─── Model preset switching ────────────────────────────────────────────────────
const modelPreset   = document.getElementById('modelPreset');
const customModelRow = document.getElementById('customModelRow');
const customModelInput = document.getElementById('customModel');

modelPreset.addEventListener('change', () => {
  const isCustom = modelPreset.value === 'custom';
  customModelRow.style.display = isCustom ? 'block' : 'none';
  if (!isCustom) saveModel(modelPreset.value);
});

customModelInput.addEventListener('change', () => {
  if (customModelInput.value.trim()) saveModel(customModelInput.value.trim());
});

function saveModel(model) {
  chrome.storage.sync.set({ model });
}

// ─── Style tabs (manual mode) ─────────────────────────────────────────────────
document.querySelectorAll('.style-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.style-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    chrome.storage.sync.set({ translationStyle: btn.dataset.style });
  });
});

// ─── Toggles (manual mode) ────────────────────────────────────────────────────
const els = {
  tone:          document.getElementById('tone'),
  useSearch:     document.getElementById('useSearch'),
  autoLike:      document.getElementById('autoLike'),
  autoInsert:    document.getElementById('autoInsert'),
  autoSendReply: document.getElementById('autoSendReply'),
  autoCloseTab:  document.getElementById('autoCloseTab'),
};

els.tone.addEventListener('change',          () => chrome.storage.sync.set({ tone: els.tone.value }));
els.useSearch.addEventListener('change',     () => chrome.storage.sync.set({ useSearch: els.useSearch.checked }));
els.autoLike.addEventListener('change',      () => chrome.storage.sync.set({ autoLike: els.autoLike.checked }));
els.autoInsert.addEventListener('change',    () => chrome.storage.sync.set({ autoInsert: els.autoInsert.checked }));
els.autoSendReply.addEventListener('change', () => chrome.storage.sync.set({ autoSendReply: els.autoSendReply.checked }));
els.autoCloseTab.addEventListener('change',  () => chrome.storage.sync.set({ autoCloseTab: els.autoCloseTab.checked }));

// ─── Load all settings ─────────────────────────────────────────────────────────
chrome.storage.sync.get([
  'tone','useSearch','autoLike','autoInsert','autoSendReply','autoCloseTab',
  'translationStyle','popupLang','popupMode','model'
], data => {
  if (data.tone)                          els.tone.value         = data.tone;
  if (data.useSearch   !== undefined)     els.useSearch.checked  = !!data.useSearch;
  if (data.autoLike    !== undefined)     els.autoLike.checked   = !!data.autoLike;
  if (data.autoInsert  !== undefined)     els.autoInsert.checked = !!data.autoInsert;
  if (data.autoSendReply !== undefined)   els.autoSendReply.checked = !!data.autoSendReply;
  if (data.autoCloseTab !== undefined)    els.autoCloseTab.checked = !!data.autoCloseTab;

  // Model preset
  const model = data.model || 'meta-llama/llama-4-scout:free';
  const knownModels = Array.from(modelPreset.options).map(o => o.value).filter(v => v !== 'custom');
  if (knownModels.includes(model)) {
    modelPreset.value = model;
  } else {
    modelPreset.value = 'custom';
    customModelRow.style.display = 'block';
    customModelInput.value = model;
  }

  // Style
  const style = data.translationStyle || 'friendly';
  document.querySelectorAll('.style-tab').forEach(b => b.classList.toggle('active', b.dataset.style === style));

  // Mode
  const mode = data.popupMode || 'auto';
  document.querySelectorAll('.mode-tab').forEach(t => t.classList.toggle('active', t.dataset.mode === mode));
  document.querySelectorAll('.mode-section').forEach(s => s.classList.toggle('active', s.id === 'section-' + mode));

  applyLang(data.popupLang || 'fa');
});

// ─── Lang buttons ─────────────────────────────────────────────────────────────
document.querySelectorAll('.lang-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    applyLang(btn.dataset.lang);
    chrome.storage.sync.set({ popupLang: btn.dataset.lang });
  });
});

// ─── Open panel buttons ────────────────────────────────────────────────────────
function openPanelOnTwitter(statusId) {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tab = tabs[0];
    if (!tab?.url?.match(/x\.com|twitter\.com/)) {
      showStatus(statusId, dict[currentLang].err_not_twitter, 'err');
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { document.getElementById('fmusicmc-ai-btn')?.click(); }
    });
    window.close();
  });
}

document.getElementById('openPanel').addEventListener('click',       () => openPanelOnTwitter('status-auto'));
document.getElementById('openPanelManual').addEventListener('click', () => openPanelOnTwitter('status-manual'));

function showStatus(id, msg, type) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = msg;
  el.className   = 'status ' + type;
  setTimeout(() => { el.className = 'status'; }, 3000);
}
