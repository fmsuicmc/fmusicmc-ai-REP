// content.js
(function() {
  const STYLE_ID = 'fmusicmc-ai-style';
  const BTN_ID = 'fmusicmc-ai-btn';
  const PANEL_ID = 'fmusicmc-ai-panel';

  // Inject styles
  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const link = document.createElement('link');
    link.id = STYLE_ID;
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('styles/overlay.css');
    document.documentElement.appendChild(link);
  }

  function createPanel() {
    let panel = document.getElementById(PANEL_ID);
    if (panel) return panel;

    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.className = 'fm-overlay';
    panel.innerHTML = `
      <div class="fm-header">
        <div class="fm-title">fmusicmc ai</div>
        <button class="fm-close" aria-label="Close">×</button>
      </div>
      <div class="fm-body">
        <textarea id="fm-input" class="fm-text" placeholder="متن توییت شناسایی شده اینجاست…"></textarea>
        <div class="fm-controls">
          <label>تون:</label>
          <select id="fm-tone">
            <option value="friendly">دوستانه</option>
            <option value="professional">حرفه‌ای</option>
            <option value="witty">طنز ملایم</option>
            <option value="analytical">تحلیلی</option>
            <option value="neutral">خنثی</option>
          </select>
          <label class="fm-check"><input type="checkbox" id="fm-search" checked> جستجو</label>
          <button id="fm-generate" class="fm-primary">تولید پاسخ</button>
        </div>
        <textarea id="fm-output" class="fm-text" placeholder="پاسخ آماده اینجا می‌آید…" readonly></textarea>
        <div class="fm-actions">
          <button id="fm-insert" class="fm-secondary">قرار دادن در باکس ریپلای</button>
          <button id="fm-copy" class="fm-ghost">کپی</button>
        </div>
      </div>
    `;
    document.body.appendChild(panel);

    panel.querySelector('.fm-close')?.addEventListener('click', () => panel.classList.remove('open'));
    panel.addEventListener('keydown', (e) => { if (e.key === 'Escape') panel.classList.remove('open'); });
    return panel;
  }

  function ensureButton() {
    if (document.getElementById(BTN_ID)) return;
    const btn = document.createElement('button');
    btn.id = BTN_ID;
    btn.textContent = 'fmusicmc ai';
    btn.className = 'fm-fab';
    btn.title = 'ساخت پاسخ هوشمند';
    btn.addEventListener('click', onOpen);
    document.body.appendChild(btn);
  }

  function getActiveTweetText() {
    // 1) Tweet detail page
    const detail = document.querySelector('article [data-testid="tweetText"]');
    if (detail && detail.innerText?.trim()) return detail.innerText.trim();

    // 2) First visible tweet on viewport
    const articles = Array.from(document.querySelectorAll('article'));
    for (const a of articles) {
      const box = a.getBoundingClientRect();
      if (box.bottom > 120 && box.top < window.innerHeight - 120) {
        const t = a.querySelector('[data-testid="tweetText"]');
        if (t && t.innerText?.trim()) return t.innerText.trim();
      }
    }

    // 3) Fallback: selected text
    const sel = window.getSelection()?.toString().trim();
    if (sel) return sel;

    return '';
  }

  function fillReplyBox(text) {
    // Try the reply composer contenteditable
    const composer = document.querySelector('div[data-testid="tweetTextarea_0"] div[contenteditable="true"]')
      || document.querySelector('div[contenteditable="true"][data-testid="tweetTextarea_0"]')
      || document.querySelector('div[contenteditable="true"]');

    if (composer) {
      composer.focus();
      try {
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, text);
        return true;
      } catch (e) {
        // fallback: set textContent and dispatch input event
        composer.textContent = text;
        composer.dispatchEvent(new InputEvent('input', { bubbles: true }));
        return true;
      }
    }
    return false;
  }

  async function onOpen() {
    ensureStyles();
    const panel = createPanel();
    const input = panel.querySelector('#fm-input');
    const output = panel.querySelector('#fm-output');
    const tone = panel.querySelector('#fm-tone');
    const useSearch = panel.querySelector('#fm-search');
    const gen = panel.querySelector('#fm-generate');
    const insert = panel.querySelector('#fm-insert');
    const copyBtn = panel.querySelector('#fm-copy');

    input.value = getActiveTweetText() || 'متن توییت پیدا نشد. خودتان جایگزین کنید.';
    output.value = '';
    panel.classList.add('open');

    gen.onclick = () => {
      output.value = 'در حال تولید…';
      chrome.runtime.sendMessage({
        type: 'GENERATE_REPLY',
        payload: { tweetText: input.value || '', tone: tone.value, useSearch: useSearch.checked }
      }, (res) => {
        if (!res?.ok) {
          output.value = 'خطا: ' + (res?.error || 'نامشخص');
        } else {
          output.value = res.data || '';
        }
      });
    };

    insert.onclick = async () => {
      if (!output.value) return;
      const ok = fillReplyBox(output.value);
      if (!ok) {
        // as fallback, copy to clipboard
        try {
          await navigator.clipboard.writeText(output.value);
          alert('پاسخ کپی شد. با Ctrl+V در باکس ریپلای پیست کنید.');
        } catch (e) {
          alert('نتوانستم در باکس ریپلای قرار دهم. لطفاً دستی پیست کنید.');
        }
      }
    };

    copyBtn.onclick = async () => {
      if (!output.value) return;
      try {
        await navigator.clipboard.writeText(output.value);
        copyBtn.textContent = 'کپی شد!';
        setTimeout(() => (copyBtn.textContent = 'کپی'), 1200);
      } catch (e) {
        alert('اجازه‌ی کپی داده نشد.');
      }
    };
  }

  function init() {
    ensureStyles();
    ensureButton();
  }

  // kick off
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
