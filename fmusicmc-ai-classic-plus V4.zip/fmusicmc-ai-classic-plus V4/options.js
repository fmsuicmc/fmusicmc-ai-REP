// options.js
async function load() {
  const defaults = {
    enabled: true,
    tone: 'friendly',
    useSearch: true,
    maxChars: 240,
    provider: 'openai',
    endpoint: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini',
    apiKey: '',
    serpApiKey: ''
  };
  const data = await new Promise((resolve) => chrome.storage.sync.get(defaults, resolve));
  document.getElementById('provider').value = data.provider;
  document.getElementById('endpoint').value = data.endpoint;
  document.getElementById('model').value = data.model;
  document.getElementById('apiKey').value = data.apiKey;
  document.getElementById('serpApiKey').value = data.serpApiKey;
  document.getElementById('tone').value = data.tone;
  document.getElementById('maxChars').value = String(data.maxChars || 240);
  document.getElementById('useSearch').value = String(!!data.useSearch);
}

async function save() {
  const payload = {
    provider: document.getElementById('provider').value,
    endpoint: document.getElementById('endpoint').value.trim(),
    model: document.getElementById('model').value.trim(),
    apiKey: document.getElementById('apiKey').value.trim(),
    serpApiKey: document.getElementById('serpApiKey').value.trim(),
    tone: document.getElementById('tone').value,
    maxChars: parseInt(document.getElementById('maxChars').value || '240', 10),
    useSearch: document.getElementById('useSearch').value === 'true',
  };
  await new Promise((resolve) => chrome.storage.sync.set(payload, resolve));
  alert('ذخیره شد.');
}

async function resetAll() {
  await new Promise((resolve) => chrome.storage.sync.clear(resolve));
  await load();
  alert('بازنشانی شد.');
}

document.getElementById('save').addEventListener('click', save);
document.getElementById('reset').addEventListener('click', resetAll);

load();
